<?php namespace Arcanedev\LogViewer\Exceptions;

/**
 * Class     FilesystemException
 *
 * @package  Arcanedev\LogViewer\Exceptions
 * @author   ARCANEDEV <arcanedev.maroc@gmail.com>
 */
class FilesystemException extends LogViewerException {}
