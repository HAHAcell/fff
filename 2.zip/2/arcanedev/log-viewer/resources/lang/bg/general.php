<?php

return [
    'all'        => 'Всички',
    'date'       => 'Дата',
    'empty-logs' => 'Не са намерени логове!',
];
