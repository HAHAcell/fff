<?php

return [
    'all'       => 'Kõik',
    'emergency' => 'Erakorraline',
    'alert'     => 'Häire',
    'critical'  => 'Kriitiline',
    'error'     => 'Viga',
    'warning'   => 'Hoiatus',
    'notice'    => 'Teade',
    'info'      => 'Info',
    'debug'     => 'Silumine',
];
