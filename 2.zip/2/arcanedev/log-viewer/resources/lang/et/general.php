<?php

return [
    'all'        => 'Kõik',
    'date'       => 'Kuupäev',
    'empty-logs' => 'Logide nimekiri on tühi!',
];
