<?php

return [
    'all'       => 'Semua',
    'emergency' => 'Darurat',
    'alert'     => 'Waspada',
    'critical'  => 'Kritis',
    'error'     => 'Kesalahan',
    'warning'   => 'Peringatan',
    'notice'    => 'Pemberitahuan',
    'info'      => 'Info',
    'debug'     => 'Debug',
];
