<?php

return [
    'all'       => 'Tümü',
    'emergency' => 'Acil',
    'alert'     => 'Alarm',
    'critical'  => 'Kritik',
    'error'     => 'Hata',
    'warning'   => 'Uyarı',
    'notice'    => 'Bildirim',
    'info'      => 'Bilgi',
    'debug'     => 'Hata ayıklama',
];
