<?php

return [
    'all'        => 'Tümü',
    'date'       => 'Tarih',
    'empty-logs' => 'Günlük listesi boş!',
];
