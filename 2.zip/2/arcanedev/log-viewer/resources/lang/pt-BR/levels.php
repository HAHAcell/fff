<?php

return [
    'all'       => 'Todos',
    'emergency' => 'Emergência',
    'alert'     => 'Alerta',
    'critical'  => 'Crítico',
    'error'     => 'Erro',
    'warning'   => 'Aviso',
    'notice'    => 'Notícia',
    'info'      => 'Informação',
    'debug'     => 'Debug',
];
