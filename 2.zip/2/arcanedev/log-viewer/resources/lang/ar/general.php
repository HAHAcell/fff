<?php

return [
    'all'        => 'جميع',
    'date'       => 'تاريخ',
    'empty-logs' => 'قائمة سجلات فارغة!',
];
