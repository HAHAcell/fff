<?php

return [
    'all'       => 'الجميع',
    'emergency' => 'حالات الطوارئ',
    'alert'     => 'إنذار',
    'critical'  => 'حرج',
    'error'     => 'خطأ',
    'warning'   => 'تحذير',
    'notice'    => 'ملاحظة',
    'info'      => 'المعلومات',
    'debug'     => 'التصحيح',
];
