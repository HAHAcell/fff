<?php

return [
    'all'        => '全部',
    'date'       => '日期',
    'empty-logs' => '日志列表为空!',
];
