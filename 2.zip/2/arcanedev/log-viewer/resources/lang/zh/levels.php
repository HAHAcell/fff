<?php

return [
    'all'       => '全部',
    'emergency' => '危急',
    'alert'     => '紧急',
    'critical'  => '严重',
    'error'     => '错误',
    'warning'   => '警告',
    'notice'    => '注意',
    'info'      => '信息',
    'debug'     => '调试',
];
