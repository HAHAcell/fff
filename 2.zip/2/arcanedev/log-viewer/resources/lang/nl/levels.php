<?php

return [
    'all'       => 'Alle',
    'emergency' => 'Noodgeval',
    'alert'     => 'Alarm',
    'critical'  => 'Cruciaal',
    'error'     => 'Error',
    'warning'   => 'Waarschuwing',
    'notice'    => 'Opmerking',
    'info'      => 'Informatie',
    'debug'     => 'Debug',
];
