<?php namespace Arcanedev\Support\Exceptions;

/**
 * Class     PackageException
 *
 * @package  Arcanedev\Support\Exceptions
 * @author   ARCANEDEV <arcanedev.maroc@gmail.com>
 */
class PackageException extends \Exception {}
