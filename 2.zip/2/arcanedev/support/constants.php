<?php

if ( ! defined('DS')) {
    define('DS', DIRECTORY_SEPARATOR);
}
