@extends('layouts.backend')
@section('title','Console - User Info')
@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <h1>User Info
                <small>BLOGS</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="{{ route('dashboard_home') }}"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active">User Info</li>
            </ol>
        </section>
        <section class="content container-fluid">
            <div class="row">
                <div class="col-md-4">
                    <form role="form" method="POST" action="{{ route('profile_update') }}" id="editProfileForm">
                        @csrf
                        <div class="box box-default">
                            <div class="box-header with-border">
                                <h3 class="box-title">Basic Settings</h3>
                            </div>
                            <div class="box-body">
                                <div class="form-group">
                                    <label>Upload Avatar：</label>
                                    <div class="avatar-view">
                                        <a data-toggle="modal" href='#avatar-modal'>
                                            <img class="img-responsive img-circle" src="{{ $admin->avatar }}"/>
                                        </a>
                                    </div>
                                </div>
                                <div class="form-group {{$errors->has('name')?'has-error':''}}">
                                    <label for="name">User Name：</label>
                                    <input type="text" class="form-control" name="name" id="name"
                                           value="{{old('name')?old('name'):$admin->name}}">
                                    @if ($errors->has('name'))
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i>{{ $errors->first('name') }}</strong></span>
                                    @endif
                                </div>
                                <div class="form-group {{$errors->has('email')?'has-error':''}}">
                                    <label for="email">Email：</label>
                                    <input type="email" class="form-control" name="email" id="email"
                                           value="{{old('email')?old('email'):$admin->email}}">
<!--                                    <span class="help-block text-red">用于找回password，请谨慎填写。</span>-->
                                    @if ($errors->has('email'))
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i>{{ $errors->first('email') }}</strong></span>
                                    @endif
                                </div>
                            </div>
                            <div class="box-footer">
                                <button type="submit" class="btn btn-success btn-flat">提交</button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-md-4">
                    <form role="form" method="POST" action="{{route('password_update')}}" id="changePassForm">
                        @csrf
                        <div class="box box-default">
                            <div class="box-header with-border">
                                <h3 class="box-title">Password modification</h3>
                            </div>
                            <div class="box-body">

                                <div class="form-group {{$errors->has('old_password')?'has-error':''}}">
                                    <label for="old_password">Old Password：</label>
                                    <input type="password" class="form-control" name="old_password" id="old_password"
                                           placeholder="Please Enter Old Password">
                                    @if ($errors->has('old_password'))
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i>{{ $errors->first('old_password') }}</strong></span>
                                    @endif
                                </div>
                                <div class="form-group {{$errors->has('password')?'has-error':''}}">
                                    <label for="password">New Password：</label>
                                    <input type="password" class="form-control" name="password" id="password"
                                           placeholder="Please Enter New Password">
                                    @if ($errors->has('password'))
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i>{{ $errors->first('password') }}</strong></span>
                                    @endif
                                </div>
                                <div class="form-group {{$errors->has('password_confirmation')?'has-error':''}}">
                                    <label for="password_confirmation">Confirm password：</label>
                                    <input type="password" class="form-control" name="password_confirmation"
                                           id="password_confirmation" placeholder="Please enter new password agin">
                                    @if ($errors->has('password_confirmation'))
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i>{{ $errors->first('password_confirmation') }}</strong></span>
                                    @endif
                                </div>
                            </div>
                            <div class="box-footer">
                                <button type="submit" class="btn btn-success btn-flat">提交</button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-md-4">
<!--                    <div class="box box-default">
                        <div class="box-header with-border">
                            <h3 class="box-title">第三方Login绑定</h3>
                        </div>
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-4">QQ：</div>
                                <div class="col-md-8">
                                    @if(blank($admin->bindQQ))<a href="{{ route('oauth.redirect','qq') }}"
                                                                 class="btn btn-flat bg-gray">点击绑定</a>
                                    @else  <a href="javascript:void(0)" class="btn btn-flat bg-gray">已绑定
                                        ({{ $admin->qqName }})</a>
                                    <a href="javascript:void(0)" class="btn btn-flat bg-red unbind-btn" data-type="qq">解除</a>
                                    @endif
                                </div>
                            </div>
                            <div class="hr-line-dashed"></div>
                            <div class="row">
                                <div class="col-md-4">微博：</div>
                                <div class="col-md-8">
                                    @if(blank($admin->bindWeibo))<a href="{{ route('oauth.redirect','weibo') }}"
                                                                    class="btn btn-flat bg-gray">点击绑定</a>
                                    @else  <a href="javascript:void(0)" class="btn btn-flat bg-gray">已绑定
                                        ({{ $admin->weiboName }})</a>
                                    <a href="javascript:void(0)" class="btn btn-flat bg-red unbind-btn"
                                       data-type="weibo">解除</a>
                                    @endif
                                </div>
                            </div>
                            <div class="hr-line-dashed"></div>
                            <div class="row">
                                <div class="col-md-4">GitHub：</div>
                                <div class="col-md-8">
                                    @if(blank($admin->bindGithub))<a href="{{ route('oauth.redirect','github') }}"
                                                                     class="btn btn-flat bg-gray">点击绑定</a>
                                    @else  <a href="javascript:void(0)" class="btn btn-flat bg-gray">已绑定
                                        ({{ $admin->githubName }})</a>
                                    <a href="javascript:void(0)" class="btn btn-flat bg-red unbind-btn"
                                       data-type="github">解除</a>
                                    @endif
                                </div>
                            </div>
                            <form id="unbindForm" style="display: none;" action="{{ route('unbind_third_login') }}"
                                  method="post">
                                @csrf
                                <input type="hidden" name="type" id="bindType">
                            </form>
                        </div>
                    </div>-->
                </div>
            </div>
        </section>
        <div class="modal fade" id="avatar-modal">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title">Upload Avatar</h4>
                    </div>
                    <form action="{{ route('avatar_upload') }}" method="post" enctype="multipart/form-data">
                        <div class="modal-body">
                            @csrf
                            <input type="file" name="avatar" class="dropify" data-max-height="200"
                                   data-allowed-file-extensions="png jpg jpeg" data-max-file-size="2M"/>
                            <span class="help-block">The avatar supports images in PNG, JPG, and JPG formats smaller than 2MB. To ensure the quality of the avatar, please upload images in equal proportions. And ensure that the width is less than 200 pixels</span>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary btn-flat">上传</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@stop
