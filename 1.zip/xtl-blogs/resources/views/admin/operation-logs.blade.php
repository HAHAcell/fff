@extends('layouts.backend')
@section('title','Console - Operate日志')
@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <h1>Operate日志
                <small>BLOGS</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="{{ route('dashboard_home') }}"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">Content Manage</a></li>
                <li class="active">Operate日志</li>
            </ol>
        </section>
        <section class="content container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="box">
                        <div class="box-header with-border">
                            <h3 class="box-title">全部日志</h3>
                            <span>共 {{ $operation_logs->total() }}条</span>
                        </div>
                        <div class="box-body table-responsive no-padding">
                            <table class="table table-hover">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>id</th>
                                    <th>操Author</th>
                                    <th>行为</th>
                                    <th>IP</th>
                                    <th>地址</th>
                                    <th>UA</th>
                                    <th>Time</th>
                                    <th>Operate</th>
                                </tr>
                                </thead>
                                <tbody>
                                @if(!blank($operation_logs))
                                    @foreach($operation_logs as $operation_log)
                                        <tr>
                                            <td><input type="checkbox" value="{{$operation_log->id}}" name="opid"
                                                       class="i-checks"></td>
                                            <td>{{$operation_log->id}}</td>
                                            <td>{{$operation_log->operator}}</td>
                                            <td>{{$operation_log->operation}}</td>
                                            <td>{{$operation_log->ip}}</td>
                                            <td>{{$operation_log->address}}</td>
                                            <td>{{$operation_log->device."-".$operation_log->browser."-".$operation_log->platform ."-".$operation_log->device_type."-".$operation_log->language}}</td>
                                            <td>{{date('Y-m-d H:i:s',$operation_log->operation_time)}}</td>
                                            <td>
                                                <a href="javascript:void(0)" class="text-red delOperationLogs">
                                                    <i class="fa fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    @endforeach
                                @else
                                    <tr>
                                        <td valign="top" colspan="9">表中数据为空</td>
                                    </tr>
                                @endif
                                </tbody>
                            </table>
                            <form id="deleteForm" style="display: none;" action="{{route('operation_logs_destroy')}}"
                                  method="post">
                                @csrf
                                <input type="hidden" name="opid" id="deleteId">
                            </form>
                        </div>
                        <div class="box-footer clearfix">
                            <div class="pull-left">
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectAll('opid')">Select All</a>
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectEmpty('opid')">Deselect All</a>
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectReverse('opid')">Invert</a>
                                <a href="javascript:void(0)" class="btn btn-danger btn-flat"
                                   id="delSelectedOperationLogs">Delete Selected</a>
                            </div>
                            {{ $operation_logs->links('vendor.pagination.adminlte') }}
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@stop
