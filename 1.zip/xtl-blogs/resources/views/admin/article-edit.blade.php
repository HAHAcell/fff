@extends('layouts.backend')
@section('title','Console - Edit Article')
@section('css')
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/inscrybmde@1/dist/inscrybmde.min.css">
    <link rel="stylesheet" href="{{ asset('css/editor.custom.css') }}">
@stop
@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <h1>Edit Article
                <small>BLOGS</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="{{ route('dashboard_home') }}"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="{{ route('article_manage') }}">Article Manage</a></li>
                <li class="active">Edit Article</li>
            </ol>
        </section>
        <section class="content container-fluid">
            <form role="form" method="POST" action="{{route('article_update',$article->id)}}" id="editArticleForm">
                @csrf
                <div class="row">
                    <div class="col-md-12">
                        <div class="box box-solid">
                            <div class="box-body">
                                <button type="submit" class="btn btn-success btn-flat" id="article_submit"><i
                                        class="fa fa-check"></i>&nbsp;Publish
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="box box-default">
                            <div class="box-header with-border">
                                <h3 class="box-title">Edit Article</h3>
                            </div>
                            <div class="box-body">
                                <div class="form-group {{$errors->has('title')?'has-error':''}}">
                                    <label for="title">Title：</label>
                                    <input type="text" class="form-control" name="title" id="title" placeholder="Please Enter Title"
                                           value="{{ old('title')?old('title'):$article->title }}">
                                    @if ($errors->has('title'))
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i>{{ $errors->first('title') }}</strong></span>
                                    @endif
                                </div>
                                <div class="form-group {{$errors->has('category_id')?'has-error':''}}">
                                    <label for="category_id">Column：</label>
                                    <select class="form-control {{$errors->has('category_id')?'has-error':''}}"
                                            name="category_id" id="category_id">
                                        <option value="1">Default</option>
<!--                                        {!! $category !!}-->
                                    </select>
                                    @if ($errors->has('category_id'))
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i>{{ $errors->first('category_id') }}</strong></span>
                                    @endif
                                </div>
                                <div class="form-group {{$errors->has('tag_ids')?'has-error':''}}">
                                    <label for="tag_ids">Label：</label>
                                    <div class="checkbox">
                                        @foreach( $tag as $tag_v)
                                            <label><input type="checkbox" class="i-checks" value="{{$tag_v->id}}"
                                                          name="tag_ids[]"
                                                          @if(in_array($tag_v->id, $article->tag_ids)) checked="checked" @endif>&nbsp;{{$tag_v->name}}
                                            </label>
                                        @endforeach
                                    </div>
                                    @if ($errors->has('tag_ids'))
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i>{{ $errors->first('tag_ids') }}</strong></span>
                                    @endif
                                </div>

                                <div class="form-group {{$errors->has('author')?'has-error':''}}">
                                    <label for="author">Author：</label>
                                    <input type="text" class="form-control" name="author" id="author"
                                           placeholder="Please EnterAuthor"
                                           value="{{ old('author') ? old('author') : $article->author}}">
                                    @if ($errors->has('author'))
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i>{{ $errors->first('author') }}</strong></span>
                                    @endif
                                </div>
                                <div class="form-group {{$errors->has('keywords')?'has-error':''}}">
                                    <label for="keywords">Keyword：</label>
                                    <input type="text" class="form-control" name="keywords" id="keywords"
                                           placeholder="Please Enter Keyword"
                                           value="{{old('keywords')?old('keywords'):$article->keywords}}">
                                    @if ($errors->has('keywords'))
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i>{{ $errors->first('keywords') }}</strong></span>
                                    @endif
                                </div>
                                <div class="form-group {{$errors->has('description')?'has-error':''}}">
                                    <label for="description">Describe：</label>
                                    <input type="text" class="form-control" name="description" id="description"
                                           placeholder="Please Enter Describe"
                                           value="{{old('description')?old('description'):$article->description}}">
                                    @if ($errors->has('description'))
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i>{{ $errors->first('description') }}</strong></span>
                                    @endif
                                </div>
                                <div class="form-group {{$errors->has('status')?'has-error':''}}">
                                    <label>Publish：</label>
                                    <div class="radio">
                                        <label class="i-checks">
                                            <input type="radio" name="status"
                                                   value="{{ \App\Models\Article::PUBLISHED }}"
                                                   @if(!is_null(old('status')) && old( 'status') == \App\Models\Article::PUBLISHED) checked="checked"
                                                   @elseif($article->status == \App\Models\Article::PUBLISHED ) checked="checked" @endif>
                                            &nbsp; yes
                                        </label>
                                        <label class="i-checks">
                                            <input type="radio" name="status"
                                                   value="{{ \App\Models\Article::UNPUBLISHED }}"
                                                   @if(!is_null(old('status')) && old( 'status') == \App\Models\Article::UNPUBLISHED) checked="checked"
                                                   @elseif($article->status == \App\Models\Article::UNPUBLISHED ) checked="checked" @endif>
                                            &nbsp; no
                                        </label>
                                    </div>
                                    @if ($errors->has('status'))
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i>{{ $errors->first('status') }}</strong></span>
                                    @endif
                                </div>
                                <div class="form-group {{$errors->has('is_top')?'has-error':''}}">
                                    <label>Top：</label>
                                    <div class="radio">
                                        <label class="i-checks">
                                            <input type="radio" name="is_top"
                                                   value="{{ \App\Models\Article::IS_TOP }}"
                                                   @if(!is_null(old('is_top')) && old('is_top') == \App\Models\Article::IS_TOP) checked="checked"
                                                   @elseif($article->is_top == \App\Models\Article::IS_TOP ) checked="checked" @endif>
                                            &nbsp; yes
                                        </label>
                                        <label class="i-checks">
                                            <input type="radio" name="is_top"
                                                   value="{{ \App\Models\Article::IS_NORMAL }}"
                                                   @if(!is_null(old('is_top')) && old( 'is_top') == \App\Models\Article::IS_NORMAL) checked="checked"
                                                   @elseif($article->is_top == \App\Models\Article::IS_NORMAL ) checked="checked" @endif>
                                            &nbsp; no
                                        </label>
                                    </div>
                                    @if ($errors->has('is_top'))
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i>{{ $errors->first('is_top') }}</strong></span>
                                    @endif
                                </div>
                                <div class="form-group {{$errors->has('allow_comment')?'has-error':''}}">
                                    <label>Hot：</label>
                                    <div class="radio">
                                        <label class="i-checks">
                                            <input type="radio" name="allow_comment"
                                                   value="{{ \App\Models\Article::ALLOW_COMMENT }}"
                                                   @if(!is_null(old('allow_comment')) && old( 'allow_comment') == \App\Models\Article::ALLOW_COMMENT) checked="checked"
                                                   @elseif($article->allow_comment == \App\Models\Article::ALLOW_COMMENT ) checked="checked" @endif>
                                            &nbsp;yes
                                        </label>
                                        <label class="i-checks">
                                            <input type="radio" name="allow_comment"
                                                   value="{{ \App\Models\Article::FORBID_COMMENT }}"
                                                   @if(!is_null(old('allow_comment')) && old( 'allow_comment') == \App\Models\Article::FORBID_COMMENT) checked="checked"
                                                   @elseif($article->allow_comment == \App\Models\Article::FORBID_COMMENT ) checked="checked" @endif>
                                            &nbsp;no
                                        </label>
                                    </div>
                                    @if ($errors->has('allow_comment'))
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i>{{ $errors->first('allow_comment') }}</strong></span>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="box">
                            <div class="box-header with-border">
                                <h3 class="box-title">Content</h3>
                            </div>
                            <div class="box-body">
                                <div class=" form-group {{$errors->has('content')?'has-error':''}}">
                                    @if ($errors->has('content'))
                                        <span class="help-block"><strong><i
                                                    class="fa fa-times-circle-o"></i>{{ $errors->first('content') }}</strong></span>
                                    @endif
                                    <textarea name="content" id="mde"
                                              style="display:none;">{{old('content')?old('content'):$article->feed->content}}</textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </section>
    </div>
@stop
@section('js')
    <script src="https://cdn.jsdelivr.net/npm/inscrybmde@1/dist/inscrybmde.min.js"></script>
    <script
        src="https://cdn.jsdelivr.net/combine/npm/inline-attachment@2/src/inline-attachment.min.js,npm/inline-attachment@2/src/codemirror-4.inline-attachment.min.js"></script>
    <script>
        $(function () {
            var mdeditor = new InscrybMDE({
                autoDownloadFontAwesome: false,
                autofocus: true,
                autosave: {
                    enabled: true,
                    uniqueId: "editArticleContent" + "{{ $article->id }}",
                    delay: 1000,
                },
                blockStyles: {
                    bold: "__",
                    italic: "_"
                },
                element: $("#mde")[0],
                forceSync: true,
                indentWithTabs: false,
                insertTexts: {
                    horizontalRule: ["", "\n\n-----\n\n"],
                    image: ["![](http://", ")"],
                    link: ["[", "](http://)"],
                    table: ["",
                        "\n\n| Column 1 | Column 2 | Column 3 |\n| -------- | -------- | -------- |\n| Text | Text | Text |\n\n"
                    ],
                },
                minHeight: "480px",
                parsingConfig: {
                    allowAtxHeaderWithoutSpace: true,
                    strikethrough: true,
                    underscoresBreakWords: true,
                },
                placeholder: "Please Enter Content...",
                renderingConfig: {
                    singleLineBreaks: true,
                    codeSyntaxHighlighting: false,
                },
                spellChecker: false,
                status: ["autosave", "lines", "words", "cursor"],
                styleSelectedText: true,
                syncSideBySidePreviewScroll: true,
                tabSize: 4,
                toolbar: [
                    "bold", "italic", "strikethrough", "heading", "|", "quote", "code", "table",
                    "horizontal-rule", "unordered-list", "ordered-list", "|",
                    "link", "image", "|", "side-by-side", 'fullscreen', "|",
                    {
                        name: "guide",
                        action: function customFunction(editor) {
                            var win = window.open(
                                'https://github.com/riku/Markdown-Syntax-CN/blob/master/syntax.md',
                                '_blank');
                            if (win) {
                                win.focus();
                            } else {
                                alert('Please allow popups for this website');
                            }
                        },
                        className: "fa fa-info-circle",
                        title: "Markdown 语法！",
                    },
                    {
                        name: "publish",
                        action: function customFunction(editor) {
                            $('#article_submit').click();
                            editor.clearAutosavedValue();
                        },
                        className: "fa fa-paper-plane",
                        title: "提交",
                    }
                ],
                toolbarTips: true,
            });
            mdeditor.codemirror.setSize('auto', '640px');
            mdeditor.codemirror.on('optionChange', (item) => {
                let fullscreen = item.getOption('fullScreen');
                if (fullscreen)
                    $(".editor-toolbar,.fullscreen,.CodeMirror-fullscreen").css('z-index', '9998');
            });
            inlineAttachment.editors.codemirror4.attach(mdeditor.codemirror, {
                uploadUrl: '{{ route('article_image_upload') }}',
                uploadFieldName: 'mde-image-file',
                progressText: '![正在上传文件...]()',
                urlText: "\n ![未命名]({filename}) \n\n",
                extraParams: {
                    "_token": '{{ csrf_token() }}'
                },
                onFileUploadResponse: function (xhr) {
                    var result = JSON.parse(xhr.responseText),
                        filename = result[this.settings.jsonFieldName];

                    if (result && filename) {
                        var newValue;
                        if (typeof this.settings.urlText === 'function') {
                            newValue = this.settings.urlText.call(this, filename, result);
                        } else {
                            newValue = this.settings.urlText.replace(this.filenameTag, filename);
                        }
                        var text = this.editor.getValue().replace(this.lastValue, newValue);
                        this.editor.setValue(text);
                        this.settings.onFileUploaded.call(this, filename);
                    }
                    return false;
                }
            });
        });
    </script>
@stop

