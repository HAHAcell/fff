<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>关站中</title>
</head>
<body>
<div style="text-align:center">
    <h2>{{$config['site_close_word']}}</h2>
</div>
</body>
</html>
