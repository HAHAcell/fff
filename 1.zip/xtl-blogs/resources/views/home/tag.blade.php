@extends('layouts.frontend')
@section('title', $tag->name)
@section('content')
    <div class="col-md-8">
        @if(blank($articles))
            <div class="callout callout-danger">
                <h4>Oops！</h4>
                <p>未找到相关文章</p>
            </div>
        @else
            <div class="box box-solid">
                <div class="box-body">
                    <h3>与<span class="text-red">"{{$tag->name}}"</span>相关的文章</h3>
                </div>
            </div>
            @foreach($articles as $article)
                <div class="box box-solid">
                    <div class="box-body article-body">
                        <a href="{{route('article',$article->id)}}" class="title-link">
                            <h3>
                                {{$article->title}}
                            </h3>
                        </a>
                        <div class="small m-b-xs">
                            <strong>{{$article->author}}</strong>&nbsp;&nbsp;<span class="text-muted"><i
                                    class="fa fa-clock-o"></i>&nbsp;Last updated on&nbsp;{{\App\Helpers\Extensions\Tool::transformTime($article->feed_updated_at)}}</span>
                        </div>
                        <div class="description">
                            <p style="word-wrap:break-word;">{{$article->description}}</p>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <h5>Label：</h5>
                                @foreach($article->tags as $tag)
                                    <a href="#"
                                       @switch(($tag->id)%5) @case(0)class="tag btn btn-flat btn-xs bg-black"
                                       @break @case(1)class="tag btn btn-flat btn-xs bg-olive"
                                       @break @case(2)class="tag btn btn-flat btn-xs bg-blue"
                                       @break @case(3)class="tag btn btn-flat btn-xs bg-purple"
                                       @break @default class="tag btn btn-flat btn-xs bg-maroon" @endswitch><i
                                            class="fa fa-tag"></i>&nbsp;{{$tag->name}}</a>
                                @endforeach
                            </div>
                            <div class="col-md-6">
                                <div class="small text-right">
                                    <h5>Status：</h5>
                                    <div><i class="fa fa-comments-o"> </i> {{ $article->comment_count }} 评论</div>
                                    <i class="fa fa-eye"> </i> {{$article->click}} browse
                                </div>
                            </div>
                        </div>
                        <div class="hr-line-dashed"></div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="pull-right">
                                    <a href="{{route('article',$article->id)}}" class="btn btn-flat bg-black tag"><i
                                            class="fa fa-eye"></i> More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
            {{$articles->links()}}
        @endif
    </div>
@stop
