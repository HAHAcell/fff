@extends('errors::layout')

@section('title', '出错了')

@section('message', 'Ops，出错了，请检查地址yes否正确或稍后重试！')
