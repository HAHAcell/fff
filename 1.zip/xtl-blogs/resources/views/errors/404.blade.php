@extends('errors::layout')

@section('title', '出错了')

@section('message', 'Ops，页面没有找到，请检查地址yes否正确！')
