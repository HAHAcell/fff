@extends('errors::layout')

@section('title', '出错了')

@section('message', 'Ops，权限不足，请检查地址yes否正确或者联系管理员！')
