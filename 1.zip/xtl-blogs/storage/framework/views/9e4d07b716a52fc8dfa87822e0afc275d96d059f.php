<?php if(\Illuminate\Support\Facades\Session::has('alertMessage')): ?>
    <script>
        $(function () {
            <?php if(\Illuminate\Support\Facades\Session::get('alertType')=='success'): ?>
            swal("Operate Success", "<?php echo e(\Illuminate\Support\Facades\Session::get('alertMessage')); ?>", "success");
            <?php else: ?>
            swal("Operate失败", "<?php echo e(\Illuminate\Support\Facades\Session::get('alertMessage')); ?>", "error");
            <?php endif; ?>
        });
    </script>
<?php endif; ?>
<?php /**PATH D:\CODES2\xtl-blogs\resources\views/vendor/message.blade.php ENDPATH**/ ?>