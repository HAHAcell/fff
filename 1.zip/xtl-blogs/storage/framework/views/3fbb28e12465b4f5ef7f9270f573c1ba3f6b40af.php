<?php $__env->startSection('title','BLOGS - password重置'); ?>
<?php $__env->startSection('name','register'); ?>
<?php $__env->startSection('content'); ?>
    <div class="register-box-body">
        <p class="login-box-msg">password重置</p>
        <form action="<?php echo e(route('password.request')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="token" value="<?php echo e($token); ?>">
            <div class="form-group <?php echo e($errors->has('email')?'has-error':'has-feedback'); ?>">
                <input id="email" type="email" class="form-control" name="email" value="<?php echo e($email or old('email')); ?>"
                       placeholder="Email"
                       required autofocus>
                <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
                <?php if($errors->has('email')): ?>
                    <span class="help-block"><strong><?php echo e($errors->first('email')); ?></strong></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('password')?'has-error':'has-feedback'); ?>">
                <input id="password" type="password" class="form-control" name="password" placeholder="password" required>
                <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                <?php if($errors->has('password')): ?>
                    <span class="help-block"><strong><?php echo e($errors->first('password')); ?></strong></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('password_confirmation')?'has-error':'has-feedback'); ?>">
                <input id="password-confirm" type="password" class="form-control" name="password_confirmation"
                       placeholder="再次输入password" required>
                <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                <?php if($errors->has('password_confirmation')): ?>
                    <span class="help-block"><strong><?php echo e($errors->first('password_confirmation')); ?></strong></span>
                <?php endif; ?>
            </div>
            <div class="row">
                <div class="col-xs-8"></div>
                <div class="col-xs-4">
                    <button type="submit" class="btn btn-primary btn-block btn-flat">重置</button>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login-register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODES2\xtl-blogs\resources\views\auth\passwords\reset.blade.php ENDPATH**/ ?>
