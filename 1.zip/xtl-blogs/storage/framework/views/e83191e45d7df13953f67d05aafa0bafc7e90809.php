<?php $__env->startSection('title','Console - 用户管理'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>用户管理
                <small>BLOGS</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('dashboard_home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">权限管理</a></li>
                <li class="active">用户管理</li>
            </ol>
        </section>
        <section class="content container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="box box-solid">
                        <div class="box-body">
                            <a href="<?php echo e(route('user_create')); ?>" class="btn btn-success btn-flat"><i
                                    class="fa fa-user-plus"></i>&nbsp;添加用户</a>&nbsp;&nbsp;
                            <a href="<?php echo e(route('user_trash')); ?>" class="btn btn-danger btn-flat"><i
                                    class="fa fa-user"></i>&nbsp;小黑屋</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="box">
                        <div class="box-header">
                            <h3 class="box-title">全部用户</h3>
                            <span>共 <?php echo e($users->total()); ?>个</span>
                            <form action="<?php echo e(route('user_search')); ?>" method="get" style="display: inline-flex"
                                  class="pull-right">
                                <div class="box-tools">
                                    <div class="input-group input-group-sm" style="width: 150px;">
                                        <input type="text" name="keyword" class="form-control" placeholder="Search ">

                                        <span class="input-group-btn">
                                            <button type="submit" class="btn btn-default"><i
                                                    class="fa fa-search"></i></button>
                                        </span>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="box-body table-responsive no-padding">
                            <table class="table table-hover">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>ID</th>
                                    <th>User Name</th>
                                    <th>角色</th>
                                    <th>Email</th>
                                    <th>用户Status</th>
                                    <th>最后Login</th>
                                    <th>添加Time</th>
                                    <th>Operate</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if(!blank($users)): ?>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><input type="checkbox" value="<?php echo e($user->id); ?>" name="uid"
                                                       class="i-checks"></td>
                                            <td><?php echo e($user->id); ?></td>
                                            <td><?php echo e($user->name); ?></td>
                                            <td><?php echo $user->all_roles_tag; ?></td>
                                            <td><?php echo e($user->email); ?></td>
                                            <td><?php echo $user->status_tag; ?></td>
                                            <td><?php echo e($user->last_login_at); ?></td>
                                            <td><?php echo e($user->created_at); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('user_edit',$user->id)); ?>" class="text-green">
                                                    <i class="fa fa-pencil-square-o"></i>
                                                </a>&nbsp;&nbsp;
                                                <a href="javascript:void(0)" class="text-red delUser">
                                                    <i class="fa fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td valign="top" colspan="8">表中数据为空</td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                            <form id="deleteForm" style="display: none;" action="<?php echo e(route('user_delete')); ?>"
                                  method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="uid" id="deleteId">
                            </form>
                        </div>
                        <div class="box-footer clearfix">
                            <div class="pull-left">
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectAll('uid')">Select All</a>
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectEmpty('uid')">Deselect All</a>
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectReverse('uid')">Invert</a>
                                <a href="javascript:void(0)" class="btn btn-danger btn-flat"
                                   id="delSelectedUser">Delete Selected</a>
                            </div>
                            <?php if(request()->has('keyword')): ?>
                                <?php echo e($users->appends(['keyword' => request()->input('keyword')])->links('vendor.pagination.adminlte')); ?>

                            <?php else: ?>
                                <?php echo e($users->links('vendor.pagination.adminlte')); ?>

                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODES2\xtl-blogs\resources\views\admin\permission\user.blade.php ENDPATH**/ ?>
