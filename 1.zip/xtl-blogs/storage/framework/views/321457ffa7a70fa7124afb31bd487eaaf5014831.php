<?php $__env->startSection('title','BLOGS - 注册'); ?>
<?php $__env->startSection('name','register'); ?>
<?php $__env->startSection('content'); ?>
    <div class="register-box-body">
        <p class="login-box-msg">注册</p>
        <form action="<?php echo e(route('register')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group <?php echo e($errors->has('name')?'has-error':'has-feedback'); ?>">
                <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" placeholder="姓名"
                       required autofocus>
                <span class="glyphicon glyphicon-user form-control-feedback"></span>
                <?php if($errors->has('name')): ?>
                    <span class="help-block"><strong><?php echo e($errors->first('name')); ?></strong></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('email')?'has-error':'has-feedback'); ?>">
                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>"
                       placeholder="Email"
                       required autofocus>
                <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
                <?php if($errors->has('email')): ?>
                    <span class="help-block"><strong><?php echo e($errors->first('email')); ?></strong></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('password')?'has-error':'has-feedback'); ?>">
                <input id="password" type="password" class="form-control" name="password" placeholder="password" required>
                <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                <?php if($errors->has('password')): ?>
                    <span class="help-block"><strong><?php echo e($errors->first('password')); ?></strong></span>
                <?php endif; ?>
            </div>
            <div class="form-group has-feedback">
                <input id="password-confirm" type="password" class="form-control" name="password_confirmation"
                       placeholder="再次输入password" required>
                <span class="glyphicon glyphicon-log-in form-control-feedback"></span>
            </div>
            <div class="row">
                <div class="col-xs-8"></div>
                <div class="col-xs-4">
                    <button type="submit" class="btn btn-primary btn-block btn-flat">注册</button>
                </div>
            </div>
        </form>
        <a href="<?php echo e(route('login')); ?>" class="text-center">我有会员帐号</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login-register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODES2\xtl-blogs\resources\views\auth\register.blade.php ENDPATH**/ ?>
