<?php $__env->startSection('title','Console - Home'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>Home
                <small>BLOGS</small>
            </h1>
        </section>
        <section class="content container-fluid">
<!--            <?php if(session('status')): ?>
                <div class="callout callout-success">
                    <p><?php echo e(session('status')); ?></p>
                </div>
            <?php endif; ?>
            <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h4><i class="icon fa fa-check"></i> 您好!</h4>
                <p><?php echo e(Auth::user()->name); ?>，欢迎访问BLOGS</p>
                <p>在这里您可以尽情的书写你的创意</p>
            </div>-->
            <div class="row">
<!--                <div class="col-lg-3 col-xs-6">

                    <div class="small-box bg-green">
                        <div class="inner">
                            <h3><?php echo e($articlesCount); ?></h3>

                            <p>我的文章</p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-file-text"></i>
                        </div>
                        <a href="<?php echo e(route('article_manage')); ?>" class="small-box-footer">更多信息
                            <i class="fa fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-xs-6">

                    <div class="small-box bg-blue">
                        <div class="inner">
                            <h3><?php echo e($pagesCount); ?></h3>

                            <p>我的单页</p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-file"></i>
                        </div>
                        <a href="<?php echo e(route('page_manage')); ?>" class="small-box-footer">更多信息
                            <i class="fa fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-xs-6">

                    <div class="small-box bg-olive">
                        <div class="inner">
                            <h3><?php echo e($commentsCount); ?></h3>

                            <p>我的评论</p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-comments"></i>
                        </div>
                        <a href="<?php echo e(route('comment_manage')); ?>" class="small-box-footer">更多信息
                            <i class="fa fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-xs-6">

                    <div class="small-box bg-purple">
                        <div class="inner">
                            <h3><?php echo e($messagesCount); ?></h3>

                            <p>我的留言</p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-comment"></i>
                        </div>
                        <a href="<?php echo e(route('message_manage')); ?>" class="small-box-footer">更多信息
                            <i class="fa fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>-->
            </div>
            <div class="row">
                <div class="col-lg-6">
                    <div class="box box-default">
                        <div class="box-header">
                            <i class="ion ion-clipboard"></i>
                            <h3 class="box-title">New Article</h3>
                        </div>
                        <div class="box-body table-responsive no-padding">
                            <table class="table table-hover">
                                <tr>
                                    <th>#</th>
                                    <th>Title</th>
                                    <th>Time</th>
                                </tr>
                                <?php $__currentLoopData = $newArticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($article->id); ?>.</td>
                                        <td><a class="text-black"
                                               href="<?php echo e(route('article_edit',$article->id)); ?>"><?php echo e($article->title); ?></a>
                                        </td>
                                        <td>
                                            <?php echo e($article->created_at); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                        <div class="box-footer clearfix">
                            <a href="<?php echo e(route('article_manage')); ?>" class="btn btn-flat bg-blue pull-right">View More</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
<!--                    <div class="box box-default">
                        <div class="box-header">
                            <i class="fa fa-comments-o"></i>
                            <h3 class="box-title">最新留言</h3>
                        </div>
                        <div class="box-body chat" id="chat-box">
                            <?php if(blank($newMessages)): ?>
                                <div class="text-center">
                                    <h4>Oops！</h4>
                                    <p>暂无新留言</p>
                                </div>
                            <?php else: ?>
                                <?php $__currentLoopData = $newMessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="item">
                                        <img src="<?php echo e(asset('img/user_avatar.png')); ?>" alt="<?php echo e($message->nickname); ?>"
                                             class="online">
                                        <p class="message">
                                            <a href="#" class="name">
                                                <small class="text-muted pull-right">
                                                    <i class="fa fa-clock-o"></i> <?php echo e($message->created_at); ?></small>
                                                <?php echo e($message->nickname); ?>

                                            </a>
                                            <?php echo e($message->content); ?>

                                        </p>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="box box-default">
                        <div class="box-header">
                            <i class="fa fa-comments-o"></i>
                            <h3 class="box-title">最新评论</h3>
                        </div>
                        <div class="box-body chat" id="chat-box">
                            <?php if(blank($newComments)): ?>
                                <div class="text-center">
                                    <h4>Oops！</h4>
                                    <p>暂无新评论</p>
                                </div>
                            <?php else: ?>
                                <?php $__currentLoopData = $newComments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="item">
                                        <img src="<?php echo e(asset('img/user_avatar.png')); ?>" alt="<?php echo e($comment->nickname); ?>"
                                             class="online">
                                        <p class="message">
                                            <a href="#" class="name">
                                                <small class="text-muted pull-right">
                                                    <i class="fa fa-clock-o"></i> <?php echo e($comment->created_at); ?></small>
                                                <?php echo e($comment->nickname); ?>

                                            </a>
                                            <span class="text-muted">来自文章：<?php echo e($comment->article->title); ?></span><br/>
                                            <?php echo e($comment->content); ?>

                                        </p>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>-->
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODES2\xtl-blogs\resources\views\admin\index.blade.php ENDPATH**/ ?>
