<?php $__env->startSection('title', '分享站点'); ?>
<?php $__env->startSection('keywords', $config['site_keywords']); ?>
<?php $__env->startSection('description', $config['site_description']); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/markdown.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-8">
        <div class="box box-default">
            <div class="box-body">
                <div class="row">
                    <div class="col-md-12">
                        <a href="<?php echo e(route('home')); ?>" class="btn bg-black btn-flat btn-sm tag pull-left"><i
                                class="fa fa-undo"></i>&nbsp;BackHome</a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="text-center">
                            <h3>
                                分享站点
                            </h3>
                            <div class="hr-line-dashed"></div>
                        </div>
                        <div class="markdown-body" style="word-wrap:break-word;">
                            <ul>
                                <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e($link->url); ?>" target="_blank"><?php echo e($link->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODES2\xtl-blogs\resources\views\home\link.blade.php ENDPATH**/ ?>
