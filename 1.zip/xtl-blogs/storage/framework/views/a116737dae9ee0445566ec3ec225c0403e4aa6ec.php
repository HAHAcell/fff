<?php $__env->startSection('title','Console - Column管理'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>Column管理
                <small>BLOGS</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('dashboard_home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="<?php echo e(route('category_manage')); ?>">Column管理</a></li>
                <li class="active">Column管理</li>
            </ol>
        </section>
        <section class="content container-fluid">
            <div class="row">
                <div class="col-md-4">
                    <form role="form" method="POST" action="<?php echo e(route('category_update',$edit_category->id)); ?>"
                          id="editCategoryForm">
                        <?php echo csrf_field(); ?>
                        <div class="box box-default">
                            <div class="box-header with-border">
                                <h3 class="box-title">编辑Column</h3>
                            </div>
                            <div class="box-body">
                                <div class="form-group <?php echo e($errors->has('name')?'has-error':''); ?>">
                                    <label for="name">Column名：</label>
                                    <input type="text" class="form-control" name="name" id="name" placeholder="Please Enter Column名称"
                                           value="<?php echo e(old('name')?old('name'):$edit_category->name); ?>">
                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i><?php echo e($errors->first('name')); ?></strong></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="parent_id">父级Column</label>
                                    <select class="form-control <?php echo e($errors->has('parent_id')?'has-error':''); ?>"
                                            name="parent_id" id="parent_id">
                                        <option value="">Please choose Column</option>
                                        <option value="0" <?php if( 0==$edit_category->parent_id): ?> selected <?php endif; ?>>一级Column
                                        </option>
                                        <?php $__currentLoopData = $levelOne; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($cate->id); ?>"
                                                    <?php if( $cate->id==$edit_category->parent_id): ?> selected <?php endif; ?>><?php echo e($cate->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('parent_id')): ?>
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i><?php echo e($errors->first('parent_id')); ?></strong></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('flag')?'has-error':''); ?>">
                                    <label for="flag">标识：</label>
                                    <input type="text" class="form-control" name="flag" id="flag" placeholder="Please Enter Column标识"
                                           value="<?php echo e(old('flag')?old('flag'):$edit_category->flag); ?>">
                                    <?php if($errors->has('flag')): ?>
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i><?php echo e($errors->first('flag')); ?></strong></span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group <?php echo e($errors->has('sort')?'has-error':''); ?>">
                                    <label for="sort">排序权重：</label>
                                    <input type="text" class="form-control" name="sort" id="sort"
                                           placeholder="Please Enter 数字，Default为0"
                                           value="<?php echo e(old('sort')?old('sort'):$edit_category->sort); ?>">
                                    <?php if($errors->has('sort')): ?>
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i><?php echo e($errors->first('sort')); ?></strong></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('keywords')?'has-error':''); ?>">
                                    <label for="keywords">Keyword：</label>
                                    <input type="text" class="form-control" name="keywords" id="keywords"
                                           placeholder="Please Enter Keyword"
                                           value="<?php echo e(old('keywords')?old('keywords'):$edit_category->keywords); ?>">
                                    <?php if($errors->has('keywords')): ?>
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i><?php echo e($errors->first('keywords')); ?></strong></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('description')?'has-error':''); ?>">
                                    <label for="description">Describe：</label>
                                    <input type="text" class="form-control" name="description" id="description"
                                           placeholder="Please Enter Describe"
                                           value="<?php echo e(old('description')?old('description'):$edit_category->description); ?>">
                                    <?php if($errors->has('description')): ?>
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i><?php echo e($errors->first('description')); ?></strong></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="box-footer">
                                <button type="submit" class="btn btn-success btn-flat">提交</button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-md-8">
                    <div class="box">
                        <div class="box-header with-border">
                            <h3 class="box-title">全部Column</h3>
                        </div>
                        <div class="box-body table-responsive no-padding">
                            <table class="table table-hover">
                                <tr>
                                    <th style="">#</th>
                                    <th>Column名</th>
                                    <th>排序权重</th>
                                    <th>文章数</th>
                                    <th style="">Operate</th>
                                </tr>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><input type="checkbox" value="<?php echo e($category->id); ?>" name="cid"
                                                   class="i-checks"></td>
                                        <td><?php echo $category->name; ?></td>
                                        <td>
                                            <?php echo e($category->sort); ?>

                                        </td>
                                        <td>
                                            <?php echo e($category->article_count); ?>

                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('category_edit',$category->id)); ?>"
                                               class="text-green editCategory">
                                                <i class="fa fa-pencil-square-o"></i>
                                            </a>&nbsp;&nbsp;
                                            <a href="javascript:void(0)" class=" delCategory text-red">
                                                <i class="fa fa-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                            <form id="deleteForm" style="display: none;" action="<?php echo e(route('category_destroy')); ?>"
                                  method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="cid" id="deleteId">
                            </form>
                        </div>
                        <div class="box-footer clearfix">
                            <div class="pull-left">
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectAll('cid')">Select All</a>
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectEmpty('cid')">Deselect All</a>
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectReverse('cid')">Invert</a>
                                <a href="javascript:void(0)" class="btn btn-danger btn-flat" id="delSelectedCategory">Delete Selected</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODES2\xtl-blogs\resources\views\admin\category-edit.blade.php ENDPATH**/ ?>
