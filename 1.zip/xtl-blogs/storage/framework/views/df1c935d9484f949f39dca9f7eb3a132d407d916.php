<?php $__env->startSection('title','BLOGS - 通过Email重置password'); ?>
<?php $__env->startSection('name','login'); ?>
<?php $__env->startSection('content'); ?>
    <div class="login-box-body">
        <p class="login-box-msg">重置password</p>
        <?php if(session('status')): ?>
            <div class="callout callout-success">
                <p><?php echo e(session('status')); ?></p>
            </div>
        <?php endif; ?>
        <form action="<?php echo e(route('password.email')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group <?php echo e($errors->has('email')?'has-error':'has-feedback'); ?>">
                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>"
                       placeholder="Email" required autofocus>
                <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
                <?php if($errors->has('email')): ?>
                    <span class="help-block"><strong><?php echo e($errors->first('email')); ?></strong></span>
                <?php endif; ?>
            </div>
            <div class="row">
                <div class="col-xs-4"></div>
                <div class="col-xs-8">
                    <button type="submit" class="btn btn-primary btn-block btn-flat">发送找回password链接</button>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login-register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODES2\xtl-blogs\resources\views\auth\passwords\email.blade.php ENDPATH**/ ?>
