<?php $__env->startSection('title', '出错了'); ?>

<?php $__env->startSection('message', 'Ops，出错了，请检查地址yes否正确或稍后重试！'); ?>

<?php echo $__env->make('errors::layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODES2\xtl-blogs\resources\views\errors\405.blade.php ENDPATH**/ ?>
