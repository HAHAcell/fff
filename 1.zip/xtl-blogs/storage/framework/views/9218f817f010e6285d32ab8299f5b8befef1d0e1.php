<?php $__env->startSection('title','BLOGS - Login'); ?>
<?php $__env->startSection('name','login'); ?>
<?php $__env->startSection('content'); ?>
    <div class="login-box-body">
        <p class="login-box-msg">Account Login</p>
        <form action="<?php echo e(route('login')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group <?php echo e($errors->has('email')?'has-error':'has-feedback'); ?>">
                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>"
                       placeholder="Email" autofocus>
                <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
                <?php if($errors->has('email')): ?>
                    <span class="help-block"><strong><?php echo e($errors->first('email')); ?></strong></span>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('password')?'has-error':'has-feedback'); ?>">
                <input id="password" type="password" class="form-control" name="password" placeholder="Password" >
                <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                <?php if($errors->has('password')): ?>
                    <span class="help-block"><strong><?php echo e($errors->first('password')); ?></strong></span>
                <?php endif; ?>
            </div>
<!--            <div class="form-group">
                <img src="<?php echo e(captcha_src('inverse')); ?>" style="cursor: pointer"
                     onclick="this.src='<?php echo e(captcha_src('inverse')); ?>'+Math.random()">
            </div>
            <div class="form-group <?php echo e($errors->has('captcha')?'has-error':'has-feedback'); ?>">
                <input id="captcha" type="text" class="form-control" name="captcha" placeholder="验证码" required>
                <?php if($errors->has('captcha')): ?>
                    <span class="help-block"><strong><?php echo e($errors->first('captcha')); ?></strong></span>
                <?php endif; ?>
            </div>-->
            <div class="row">
                <div class="col-xs-8">
<!--                    <div class="checkbox icheck">
                        <label>
                            <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> 记住我
                        </label>
                    </div>-->
                </div>
                <div class="col-xs-4">
                    <button type="submit" class="btn btn-primary btn-block btn-flat">Login</button>
                </div>
            </div>
        </form>
        <div class="social-auth-links text-center">
<!--            <p>- 或者 -</p>-->
<!--            <a href="<?php echo e(route('oauth.redirect','qq')); ?>" class="btn btn-block btn-social  btn-flat bg-blue"><i
                    class="fa fa-qq"></i> Use
                QQ</a>
            <a href="<?php echo e(route('oauth.redirect','weibo')); ?>" class="btn btn-block btn-social  btn-flat bg-red"><i
                    class="fa fa-weibo"></i> Use
                微博</a>-->
            <a href="<?php echo e(route('oauth.redirect','github')); ?>" class="btn btn-block btn-social  btn-flat bg-black"><i
                    class="fa fa-github"></i> Use
                GitHub</a>
        </div>
<!--        <a href="<?php echo e(route('password.request')); ?>">忘记password？</a><br>-->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login-register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODES2\xtl-blogs\resources\views/auth/login.blade.php ENDPATH**/ ?>