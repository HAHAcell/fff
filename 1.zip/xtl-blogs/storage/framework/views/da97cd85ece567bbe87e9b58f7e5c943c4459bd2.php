<?php $__env->startSection('title','Console - 用户小黑屋'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>用户小黑屋
                <small>BLOGS</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('dashboard_home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">用户管理</a></li>
                <li class="active">用户小黑屋</li>
            </ol>
        </section>
        <section class="content container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="box">
                        <div class="box-header">
                            <h3 class="box-title">全部删除用户</h3>
                            <span>共 <?php echo e($users->total()); ?>个</span>
                        </div>
                        <div class="box-body table-responsive no-padding">
                            <table class="table table-hover">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>ID</th>
                                    <th>User Name</th>
                                    <th>角色</th>
                                    <th>Email</th>
                                    <th>用户Status</th>
                                    <th>删除Time</th>
                                    <th>Operate</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if(!blank($users)): ?>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><input type="checkbox" value="<?php echo e($user->id); ?>" name="uid"
                                                       class="i-checks"></td>
                                            <td><?php echo e($user->id); ?></td>
                                            <td><?php echo e($user->name); ?></td>
                                            <td><?php echo $user->all_roles_tag; ?></td>
                                            <td><?php echo e($user->email); ?></td>
                                            <td><?php echo $user->status_tag; ?></td>
                                            <td><?php echo e($user->deleted_at); ?></td>
                                            <td>
                                                <a class="text-green restoreUser"><i class="fa fa-recycle"></i></a>&nbsp;&nbsp;
                                                <a class="text-red destroyUser"><i class="fa fa-trash"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td valign="top" colspan="8">表中数据为空</td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                            <form id="restoreForm" style="display: none;" method="POST"
                                  action="<?php echo e(route('user_restore')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="uid" id="restoreId">
                            </form>
                            <form id="destroyForm" style="display: none;" method="POST"
                                  action="<?php echo e(route('user_destroy')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="uid" id="destroyId">
                            </form>
                        </div>
                        <div class="box-footer clearfix">
                            <div class="pull-left">
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectAll('uid')">Select All</a>
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectEmpty('uid')">Deselect All</a>
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectReverse('uid')">Invert</a>
                                <a href="javascript:void(0)" class="btn btn-danger btn-flat" id="destroySelectedUser">彻底Delete Selected</a>
                                <a href="javascript:void(0)" class="btn btn-success btn-flat" id="restoreSelectedUser">恢复选定</a>
                            </div>
                            <?php if(request()->has('keyword')): ?>
                                <?php echo e($users->appends(['keyword' => request()->input('keyword')])->links('vendor.pagination.adminlte')); ?>

                            <?php else: ?>
                                <?php echo e($users->links('vendor.pagination.adminlte')); ?>

                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODES2\xtl-blogs\resources\views\admin\permission\user-trash.blade.php ENDPATH**/ ?>
