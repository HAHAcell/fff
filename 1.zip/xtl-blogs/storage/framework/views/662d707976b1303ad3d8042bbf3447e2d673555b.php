<?php $__env->startSection('title','Console - Operate日志'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>Operate日志
                <small>BLOGS</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('dashboard_home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">Content Manage</a></li>
                <li class="active">Operate日志</li>
            </ol>
        </section>
        <section class="content container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="box">
                        <div class="box-header with-border">
                            <h3 class="box-title">全部日志</h3>
                            <span>共 <?php echo e($operation_logs->total()); ?>条</span>
                        </div>
                        <div class="box-body table-responsive no-padding">
                            <table class="table table-hover">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>id</th>
                                    <th>操Author</th>
                                    <th>行为</th>
                                    <th>IP</th>
                                    <th>地址</th>
                                    <th>UA</th>
                                    <th>Time</th>
                                    <th>Operate</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if(!blank($operation_logs)): ?>
                                    <?php $__currentLoopData = $operation_logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operation_log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><input type="checkbox" value="<?php echo e($operation_log->id); ?>" name="opid"
                                                       class="i-checks"></td>
                                            <td><?php echo e($operation_log->id); ?></td>
                                            <td><?php echo e($operation_log->operator); ?></td>
                                            <td><?php echo e($operation_log->operation); ?></td>
                                            <td><?php echo e($operation_log->ip); ?></td>
                                            <td><?php echo e($operation_log->address); ?></td>
                                            <td><?php echo e($operation_log->device."-".$operation_log->browser."-".$operation_log->platform ."-".$operation_log->device_type."-".$operation_log->language); ?></td>
                                            <td><?php echo e(date('Y-m-d H:i:s',$operation_log->operation_time)); ?></td>
                                            <td>
                                                <a href="javascript:void(0)" class="text-red delOperationLogs">
                                                    <i class="fa fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td valign="top" colspan="9">表中数据为空</td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                            <form id="deleteForm" style="display: none;" action="<?php echo e(route('operation_logs_destroy')); ?>"
                                  method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="opid" id="deleteId">
                            </form>
                        </div>
                        <div class="box-footer clearfix">
                            <div class="pull-left">
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectAll('opid')">Select All</a>
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectEmpty('opid')">Deselect All</a>
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectReverse('opid')">Invert</a>
                                <a href="javascript:void(0)" class="btn btn-danger btn-flat"
                                   id="delSelectedOperationLogs">Delete Selected</a>
                            </div>
                            <?php echo e($operation_logs->links('vendor.pagination.adminlte')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODES2\xtl-blogs\resources\views\admin\operation-logs.blade.php ENDPATH**/ ?>
