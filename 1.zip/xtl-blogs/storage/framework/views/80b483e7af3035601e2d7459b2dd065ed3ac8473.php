<?php $__env->startSection('title','Console - Article Manage'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>Article Manage
                <small>BLOGS</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('dashboard_home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">Content Manage</a></li>
                <li class="active">Article Manage</li>
            </ol>
        </section>
        <section class="content container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="box box-solid">
                        <div class="box-body">
                            <form action="<?php echo e(route('article_manage')); ?>" method="get">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <select class="form-control select2" name="category" id="category_id">
                                            <option value="0">Please choose Column</option>
                                            <?php echo $categories; ?>

                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <input type="text" name="keyword" class="form-control" placeholder="Search Title"
                                               value="<?php echo e(request()->input('keyword')); ?>">
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <button type="submit" class="btn btn-success btn-flat"><i class="fa fa-search"></i>&nbsp;Search
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="box">
                        <div class="box-header">
                            <h3 class="box-title">All Articles</h3>
                            <span>共 <?php echo e($articles->total()); ?>篇</span>
                        </div>
                        <div class="box-body table-responsive no-padding">
                            <table class="table table-hover">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Title</th>
                                    <th>Column</th>
                                    <th>Hits</th>
                                    <th>Create Time</th>
                                    <th>Status</th>
                                    <th>Operate</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if(!blank($articles)): ?>
                                    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><input type="checkbox" value="<?php echo e($article->id); ?>" name="aid"
                                                       class="i-checks"></td>
                                            <td><a class="text-black"
                                                   href="<?php echo e(route('article',$article->id)); ?>"><?php echo e($article->title); ?></a>
                                            </td>
                                            <td><?php echo e($article->category->name); ?></td>
                                            <td><?php echo e($article->click); ?></td>
                                            <td><?php echo e(\App\Helpers\Extensions\Tool::transformTime($article->created_at)); ?></td>
                                            <td><?php echo $article->top_tag; ?> <?php echo $article->status_tag; ?></td>
                                            <td>
                                                <a href="<?php echo e(route('article_edit',$article->id)); ?>" class="text-green">
                                                    <i class="fa fa-pencil-square-o"></i>
                                                </a>&nbsp;&nbsp;
                                                <a href="javascript:void(0)" class="text-red delArticle">
                                                    <i class="fa fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td valign="top" colspan="7">表中数据为空</td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                            <form id="deleteForm" style="display: none;" action="<?php echo e(route('article_delete')); ?>"
                                  method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="aid" id="deleteId">
                            </form>
                        </div>
                        <div class="box-footer clearfix">
                            <div class="pull-left">
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectAll('aid')">Select All</a>
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectEmpty('aid')">Deselect All</a>
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectReverse('aid')">Invert</a>
                                <a href="javascript:void(0)" class="btn btn-danger btn-flat" id="delSelectedArticle">Delete Selected</a>
                            </div>
                            <?php echo e($articles->appends(request()->input())->links('vendor.pagination.adminlte')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODES2\xtl-blogs\resources\views\admin\article.blade.php ENDPATH**/ ?>
