<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>关站中</title>
</head>
<body>
<div style="text-align:center">
    <h2><?php echo e($config['site_close_word']); ?></h2>
</div>
</body>
</html>
<?php /**PATH D:\CODES2\xtl-blogs\resources\views\home\close.blade.php ENDPATH**/ ?>