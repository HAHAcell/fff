<?php $__env->startSection('title', 'Search '); ?>
<?php $__env->startSection('keywords', $config['site_keywords']); ?>
<?php $__env->startSection('description', $config['site_description']); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-8">
        <?php if(blank($articles)): ?>
            <div class="callout callout-danger">
                <h4>Oops！</h4>
                <p>未找到相关文章</p>
            </div>
        <?php else: ?>
            <div class="box box-solid">
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-12">
                            <?php if(blank(request()->input('keyword'))): ?>
                                <h3>
                                    <span class="text-red">Please Enter 条件进行查询</span>
                                </h3>
                            <?php else: ?>
                                <h3>
                                    为您找到相关结果约<?php echo e($articles->count); ?>个： <span
                                        class="text-blue">“<?php echo e(request()->input('keyword')); ?>

                                        ”</span>
                                </h3>
                            <?php endif; ?>
                            <div class="search-form">
                                <form action="<?php echo e(route('search')); ?>" method="get">
                                    <div class="input-group">
                                        <input type="text" class="form-control"
                                               placeholder="<?php echo e(request()->input('keyword')); ?>" name="keyword">
                                        <div class="input-group-btn">
                                            <button type="submit" class="btn btn-flat bg-black">Search </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="hr-line-dashed"></div>
                                <div class="search-result">
                                    <h3><a href="<?php echo e(route('article',$article->id)); ?>"
                                           class="title-link"><?php echo e($article->title); ?></a></h3>
                                    <a href="<?php echo e(route('article',$article->id)); ?>"
                                       class="search-link"><?php echo e(route('article',$article->id)); ?></a>
                                    <div class="description">
                                        <p style="word-wrap:break-word;"><?php echo e($article->description); ?></p>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($articles->appends(['keyword' => request()->input('keyword')])->links()); ?>

                        </div>
                    </div>

                </div>
                <!-- /.box-body -->
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODES2\xtl-blogs\resources\views\home\search.blade.php ENDPATH**/ ?>
