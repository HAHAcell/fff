<?php $__env->startSection('title','Console - 权限管理'); ?>
<?php $__env->startSection('css'); ?>
    <script>var editPermissionUrl = "<?php echo e(route('permission_edit')); ?>"</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>权限管理
                <small>BLOGS</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('dashboard_home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">权限管理</a></li>
                <li class="active">权限管理</li>
            </ol>
        </section>
        <section class="content container-fluid">
            <div class="row">
                <div class="col-md-6">
                    <div class="box">
                        <div class="box-header">
                            <h3 class="box-title">全部权限</h3>
                            <span>共 <?php echo e($permissions->total()); ?>个</span>
                            <form action="<?php echo e(route('permission_search')); ?>" method="get" style="display: inline-flex"
                                  class="pull-right">
                                <div class="box-tools">
                                    <div class="input-group input-group-sm" style="width: 150px;">
                                        <input type="text" name="keyword" class="form-control" placeholder="Search ">

                                        <span class="input-group-btn">
                                            <button type="submit" class="btn btn-default"><i
                                                    class="fa fa-search"></i></button>
                                        </span>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="box-body table-responsive no-padding">
                            <table class="table table-hover">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>权限</th>
                                    <th>路由</th>
                                    <th>Operate</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if(!blank($permissions)): ?>
                                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><input type="checkbox" value="<?php echo e($permission->id); ?>" name="pid"
                                                       class="i-checks"></td>
                                            <td><?php echo e($permission->name); ?></td>
                                            <td><?php echo e($permission->route); ?></td>
                                            <td>
                                                <a href="javascript:void(0)" class="text-green editPermission">
                                                    <i class="fa fa-pencil-square-o"></i>
                                                </a>&nbsp;&nbsp;
                                                <a href="javascript:void(0)" class="text-red delPermission">
                                                    <i class="fa fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td valign="top" colspan="4">表中数据为空</td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                            <form id="deleteForm" style="display: none;" action="<?php echo e(route('permission_destroy')); ?>"
                                  method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="pid" id="deleteId">
                            </form>
                        </div>
                        <div class="box-footer clearfix">
                            <div class="pull-left">
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectAll('pid')">Select All</a>
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectEmpty('pid')">Deselect All</a>
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectReverse('pid')">Invert</a>
                                <a href="javascript:void(0)" class="btn btn-danger btn-flat" id="delSelectedPermission">Delete Selected</a>
                            </div>
                            <?php if(request()->has('keyword')): ?>
                                <?php echo e($permissions->appends(['keyword' => request()->input('keyword')])->links('vendor.pagination.adminlte')); ?>

                            <?php else: ?>
                                <?php echo e($permissions->links('vendor.pagination.adminlte')); ?>

                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <?php echo $__env->make('errors.validator', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <form role="form" method="POST" action="<?php echo e(route('permission_update')); ?>" id="editPermissionForm"
                          style="display: none">
                        <?php echo csrf_field(); ?>
                        <div class="box box-default">
                            <div class="box-header with-border">
                                <h3 class="box-title">编辑权限</h3>
                            </div>
                            <div class="box-body">
                                <input type="hidden" name="id" id="editId">
                                <div class="form-group <?php echo e($errors->has('edit_name')?'has-error':''); ?>">
                                    <label for="name">权限名：</label>
                                    <input type="text" class="form-control" name="edit_name" id="editName"
                                           placeholder="Please Enter 权限名" value="<?php echo e(old('edit_name')?old('edit_name'):''); ?>">
                                    <?php if($errors->has('edit_name')): ?>
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i><?php echo e($errors->first('edit_name')); ?></strong></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('edit_route')?'has-error':''); ?>">
                                    <label for="flag">路由：</label>
                                    <input type="text" class="form-control" name="edit_route" id="editRoute"
                                           placeholder="Please Enter 路由名称" value="<?php echo e(old('edit_route')?old('edit_route'):''); ?>">
                                    <?php if($errors->has('edit_route')): ?>
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i><?php echo e($errors->first('edit_route')); ?></strong></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="box-footer">
                                <button type="submit" class="btn btn-success btn-flat">提交</button>
                            </div>
                        </div>
                    </form>
                    <form role="form" method="POST" action="<?php echo e(route('permission_store')); ?>" id="createPermissionForm">
                        <?php echo csrf_field(); ?>
                        <div class="box box-default">
                            <div class="box-header with-border">
                                <h3 class="box-title">新建权限</h3>
                            </div>
                            <div class="box-body">
                                <div class="form-group <?php echo e($errors->has('name')?'has-error':''); ?>">
                                    <label for="name">权限名：</label>
                                    <input type="text" class="form-control" name="name" id="name" placeholder="Please Enter 权限名"
                                           value="<?php echo e(old('name')); ?>">
                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i><?php echo e($errors->first('name')); ?></strong></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('route')?'has-error':''); ?>">
                                    <label for="flag">路由：</label>
                                    <input type="text" class="form-control" name="route" id="route"
                                           placeholder="Please Enter 路由名称" value="<?php echo e(old('route')); ?>">
                                    <?php if($errors->has('route')): ?>
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i><?php echo e($errors->first('route')); ?></strong></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="box-footer">
                                <button type="submit" class="btn btn-success btn-flat">提交</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODES2\xtl-blogs\resources\views\admin\permission\permission.blade.php ENDPATH**/ ?>
