<?php $__env->startSection('title', '订阅'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-8">
        <div class="box box-solid">
            <div class="box-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="text-center">
                            <h3>
                                订阅
                            </h3>
                            <p>如果您需要及时了解本站最新Publish的文章和消息，您可以通过Email订阅本站</p>
                            <div class="hr-line-dashed"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="box box-solid">
            <div class="box-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="">
                            <?php echo $__env->make('errors.validator', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <form action="<?php echo e(route('subscribe_store')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="input-group">
                                    <input type="email" class="form-control" name="email" id="subscribe-email"
                                           placeholder="Please Enter 订阅Email" required><span class="input-group-btn"><button
                                            type="submit" class="btn btn-success btn-flat"><i
                                                class="fa fa-check"></i></button></span>
                                </div>
                                <span class="help-block text-red">如需解除订阅请联系站长</span>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODES2\xtl-blogs\resources\views\home\subscribe.blade.php ENDPATH**/ ?>
