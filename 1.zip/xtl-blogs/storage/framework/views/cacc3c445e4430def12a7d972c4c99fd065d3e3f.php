<?php $__env->startSection('title', '留言板'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-8">
        <div class="box box-solid">
            <div class="box-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="text-center">
                            <h3>
                                留言板
                            </h3>
                            <p>在这里您可以对网站提出建议，或咨询相关问题</p>
                            <div class="hr-line-dashed"></div>
                        </div>
                        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="post">
                                <div class="user-block">
                                    <img class="img-circle img-bordered-sm" src="<?php echo e(asset('img/user_avatar.png')); ?>"
                                         alt="<?php echo e($message->nickname); ?>">
                                    <span class="username">
                                <a href="#"><?php echo e($message->nickname); ?></a>
                                </span>
                                    <span class="description"><?php echo e($message->created_at); ?></span>
                                </div>
                                <!-- /.user-block -->
                                <p>
                                    <?php echo e($message->content); ?>

                                </p>
                                <?php if(isset($message->reply)): ?>
                                    <div class="post reply-post">
                                        <div class="user-block">
                                            <img class="img-circle img-bordered-sm"
                                                 src="<?php echo e($config['site_admin_avatar']); ?>"
                                                 alt="<?php echo e($config['site_admin']); ?>">
                                            <span class="username">
                                            <a href="#">站长回复</a>
                                        </span>
                                            <span class="description"><?php echo e($message->updated_at); ?></span>
                                        </div>
                                        <p>
                                            <?php echo e($message->reply); ?>

                                        </p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="post clearfix">
                            <h4 class="text-bold">给我留言：</h4>
                            <?php echo $__env->make('errors.validator', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <form role="form" action="<?php echo e(route('message_store')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-xs-12 form-group">
                                        <textarea class="form-control" style="resize: none;" rows="3" cols="4"
                                                  name="content" placeholder="Please Enter 留言" required></textarea>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4 form-group">
                                        <input type="text" class="form-control" name="nickname" placeholder="输入留言Show名称 *"
                                               required>
                                    </div>
                                    <div class="col-md-4 form-group">
                                        <input type="email" class="form-control" name="email"
                                               placeholder="输入Email（不会Show）*" required>
                                    </div>
                                    <div class="col-md-4 form-group">
                                        <button type="submit" class="btn btn-flat btn-block bg-green">留言</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODES2\xtl-blogs\resources\views\home\message.blade.php ENDPATH**/ ?>
