<?php $__env->startSection('title','Console - Edit Article'); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/inscrybmde@1/dist/inscrybmde.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/editor.custom.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>Edit Article
                <small>BLOGS</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('dashboard_home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="<?php echo e(route('article_manage')); ?>">Article Manage</a></li>
                <li class="active">Edit Article</li>
            </ol>
        </section>
        <section class="content container-fluid">
            <form role="form" method="POST" action="<?php echo e(route('article_update',$article->id)); ?>" id="editArticleForm">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="box box-solid">
                            <div class="box-body">
                                <button type="submit" class="btn btn-success btn-flat" id="article_submit"><i
                                        class="fa fa-check"></i>&nbsp;Publish
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="box box-default">
                            <div class="box-header with-border">
                                <h3 class="box-title">Edit Article</h3>
                            </div>
                            <div class="box-body">
                                <div class="form-group <?php echo e($errors->has('title')?'has-error':''); ?>">
                                    <label for="title">Title：</label>
                                    <input type="text" class="form-control" name="title" id="title" placeholder="Please Enter Title"
                                           value="<?php echo e(old('title')?old('title'):$article->title); ?>">
                                    <?php if($errors->has('title')): ?>
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i><?php echo e($errors->first('title')); ?></strong></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('category_id')?'has-error':''); ?>">
                                    <label for="category_id">Column：</label>
                                    <select class="form-control <?php echo e($errors->has('category_id')?'has-error':''); ?>"
                                            name="category_id" id="category_id">
                                        <option value="1">Default</option>
<!--                                        <?php echo $category; ?>-->
                                    </select>
                                    <?php if($errors->has('category_id')): ?>
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i><?php echo e($errors->first('category_id')); ?></strong></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('tag_ids')?'has-error':''); ?>">
                                    <label for="tag_ids">Label：</label>
                                    <div class="checkbox">
                                        <?php $__currentLoopData = $tag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag_v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <label><input type="checkbox" class="i-checks" value="<?php echo e($tag_v->id); ?>"
                                                          name="tag_ids[]"
                                                          <?php if(in_array($tag_v->id, $article->tag_ids)): ?> checked="checked" <?php endif; ?>>&nbsp;<?php echo e($tag_v->name); ?>

                                            </label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <?php if($errors->has('tag_ids')): ?>
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i><?php echo e($errors->first('tag_ids')); ?></strong></span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group <?php echo e($errors->has('author')?'has-error':''); ?>">
                                    <label for="author">Author：</label>
                                    <input type="text" class="form-control" name="author" id="author"
                                           placeholder="Please EnterAuthor"
                                           value="<?php echo e(old('author') ? old('author') : $article->author); ?>">
                                    <?php if($errors->has('author')): ?>
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i><?php echo e($errors->first('author')); ?></strong></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('keywords')?'has-error':''); ?>">
                                    <label for="keywords">Keyword：</label>
                                    <input type="text" class="form-control" name="keywords" id="keywords"
                                           placeholder="Please Enter Keyword"
                                           value="<?php echo e(old('keywords')?old('keywords'):$article->keywords); ?>">
                                    <?php if($errors->has('keywords')): ?>
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i><?php echo e($errors->first('keywords')); ?></strong></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('description')?'has-error':''); ?>">
                                    <label for="description">Describe：</label>
                                    <input type="text" class="form-control" name="description" id="description"
                                           placeholder="Please Enter Describe"
                                           value="<?php echo e(old('description')?old('description'):$article->description); ?>">
                                    <?php if($errors->has('description')): ?>
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i><?php echo e($errors->first('description')); ?></strong></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('status')?'has-error':''); ?>">
                                    <label>Publish：</label>
                                    <div class="radio">
                                        <label class="i-checks">
                                            <input type="radio" name="status"
                                                   value="<?php echo e(\App\Models\Article::PUBLISHED); ?>"
                                                   <?php if(!is_null(old('status')) && old( 'status') == \App\Models\Article::PUBLISHED): ?> checked="checked"
                                                   <?php elseif($article->status == \App\Models\Article::PUBLISHED ): ?> checked="checked" <?php endif; ?>>
                                            &nbsp; yes
                                        </label>
                                        <label class="i-checks">
                                            <input type="radio" name="status"
                                                   value="<?php echo e(\App\Models\Article::UNPUBLISHED); ?>"
                                                   <?php if(!is_null(old('status')) && old( 'status') == \App\Models\Article::UNPUBLISHED): ?> checked="checked"
                                                   <?php elseif($article->status == \App\Models\Article::UNPUBLISHED ): ?> checked="checked" <?php endif; ?>>
                                            &nbsp; no
                                        </label>
                                    </div>
                                    <?php if($errors->has('status')): ?>
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i><?php echo e($errors->first('status')); ?></strong></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('is_top')?'has-error':''); ?>">
                                    <label>Top：</label>
                                    <div class="radio">
                                        <label class="i-checks">
                                            <input type="radio" name="is_top"
                                                   value="<?php echo e(\App\Models\Article::IS_TOP); ?>"
                                                   <?php if(!is_null(old('is_top')) && old('is_top') == \App\Models\Article::IS_TOP): ?> checked="checked"
                                                   <?php elseif($article->is_top == \App\Models\Article::IS_TOP ): ?> checked="checked" <?php endif; ?>>
                                            &nbsp; yes
                                        </label>
                                        <label class="i-checks">
                                            <input type="radio" name="is_top"
                                                   value="<?php echo e(\App\Models\Article::IS_NORMAL); ?>"
                                                   <?php if(!is_null(old('is_top')) && old( 'is_top') == \App\Models\Article::IS_NORMAL): ?> checked="checked"
                                                   <?php elseif($article->is_top == \App\Models\Article::IS_NORMAL ): ?> checked="checked" <?php endif; ?>>
                                            &nbsp; no
                                        </label>
                                    </div>
                                    <?php if($errors->has('is_top')): ?>
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i><?php echo e($errors->first('is_top')); ?></strong></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('allow_comment')?'has-error':''); ?>">
                                    <label>Hot：</label>
                                    <div class="radio">
                                        <label class="i-checks">
                                            <input type="radio" name="allow_comment"
                                                   value="<?php echo e(\App\Models\Article::ALLOW_COMMENT); ?>"
                                                   <?php if(!is_null(old('allow_comment')) && old( 'allow_comment') == \App\Models\Article::ALLOW_COMMENT): ?> checked="checked"
                                                   <?php elseif($article->allow_comment == \App\Models\Article::ALLOW_COMMENT ): ?> checked="checked" <?php endif; ?>>
                                            &nbsp;yes
                                        </label>
                                        <label class="i-checks">
                                            <input type="radio" name="allow_comment"
                                                   value="<?php echo e(\App\Models\Article::FORBID_COMMENT); ?>"
                                                   <?php if(!is_null(old('allow_comment')) && old( 'allow_comment') == \App\Models\Article::FORBID_COMMENT): ?> checked="checked"
                                                   <?php elseif($article->allow_comment == \App\Models\Article::FORBID_COMMENT ): ?> checked="checked" <?php endif; ?>>
                                            &nbsp;no
                                        </label>
                                    </div>
                                    <?php if($errors->has('allow_comment')): ?>
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i><?php echo e($errors->first('allow_comment')); ?></strong></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="box">
                            <div class="box-header with-border">
                                <h3 class="box-title">Content</h3>
                            </div>
                            <div class="box-body">
                                <div class=" form-group <?php echo e($errors->has('content')?'has-error':''); ?>">
                                    <?php if($errors->has('content')): ?>
                                        <span class="help-block"><strong><i
                                                    class="fa fa-times-circle-o"></i><?php echo e($errors->first('content')); ?></strong></span>
                                    <?php endif; ?>
                                    <textarea name="content" id="mde"
                                              style="display:none;"><?php echo e(old('content')?old('content'):$article->feed->content); ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="https://cdn.jsdelivr.net/npm/inscrybmde@1/dist/inscrybmde.min.js"></script>
    <script
        src="https://cdn.jsdelivr.net/combine/npm/inline-attachment@2/src/inline-attachment.min.js,npm/inline-attachment@2/src/codemirror-4.inline-attachment.min.js"></script>
    <script>
        $(function () {
            var mdeditor = new InscrybMDE({
                autoDownloadFontAwesome: false,
                autofocus: true,
                autosave: {
                    enabled: true,
                    uniqueId: "editArticleContent" + "<?php echo e($article->id); ?>",
                    delay: 1000,
                },
                blockStyles: {
                    bold: "__",
                    italic: "_"
                },
                element: $("#mde")[0],
                forceSync: true,
                indentWithTabs: false,
                insertTexts: {
                    horizontalRule: ["", "\n\n-----\n\n"],
                    image: ["![](http://", ")"],
                    link: ["[", "](http://)"],
                    table: ["",
                        "\n\n| Column 1 | Column 2 | Column 3 |\n| -------- | -------- | -------- |\n| Text | Text | Text |\n\n"
                    ],
                },
                minHeight: "480px",
                parsingConfig: {
                    allowAtxHeaderWithoutSpace: true,
                    strikethrough: true,
                    underscoresBreakWords: true,
                },
                placeholder: "Please Enter Content...",
                renderingConfig: {
                    singleLineBreaks: true,
                    codeSyntaxHighlighting: false,
                },
                spellChecker: false,
                status: ["autosave", "lines", "words", "cursor"],
                styleSelectedText: true,
                syncSideBySidePreviewScroll: true,
                tabSize: 4,
                toolbar: [
                    "bold", "italic", "strikethrough", "heading", "|", "quote", "code", "table",
                    "horizontal-rule", "unordered-list", "ordered-list", "|",
                    "link", "image", "|", "side-by-side", 'fullscreen', "|",
                    {
                        name: "guide",
                        action: function customFunction(editor) {
                            var win = window.open(
                                'https://github.com/riku/Markdown-Syntax-CN/blob/master/syntax.md',
                                '_blank');
                            if (win) {
                                win.focus();
                            } else {
                                alert('Please allow popups for this website');
                            }
                        },
                        className: "fa fa-info-circle",
                        title: "Markdown 语法！",
                    },
                    {
                        name: "publish",
                        action: function customFunction(editor) {
                            $('#article_submit').click();
                            editor.clearAutosavedValue();
                        },
                        className: "fa fa-paper-plane",
                        title: "提交",
                    }
                ],
                toolbarTips: true,
            });
            mdeditor.codemirror.setSize('auto', '640px');
            mdeditor.codemirror.on('optionChange', (item) => {
                let fullscreen = item.getOption('fullScreen');
                if (fullscreen)
                    $(".editor-toolbar,.fullscreen,.CodeMirror-fullscreen").css('z-index', '9998');
            });
            inlineAttachment.editors.codemirror4.attach(mdeditor.codemirror, {
                uploadUrl: '<?php echo e(route('article_image_upload')); ?>',
                uploadFieldName: 'mde-image-file',
                progressText: '![正在上传文件...]()',
                urlText: "\n ![未命名]({filename}) \n\n",
                extraParams: {
                    "_token": '<?php echo e(csrf_token()); ?>'
                },
                onFileUploadResponse: function (xhr) {
                    var result = JSON.parse(xhr.responseText),
                        filename = result[this.settings.jsonFieldName];

                    if (result && filename) {
                        var newValue;
                        if (typeof this.settings.urlText === 'function') {
                            newValue = this.settings.urlText.call(this, filename, result);
                        } else {
                            newValue = this.settings.urlText.replace(this.filenameTag, filename);
                        }
                        var text = this.editor.getValue().replace(this.lastValue, newValue);
                        this.editor.setValue(text);
                        this.settings.onFileUploaded.call(this, filename);
                    }
                    return false;
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODES2\xtl-blogs\resources\views/admin/article-edit.blade.php ENDPATH**/ ?>