<?php $__env->startSection('title','Console - 添加用户'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>添加用户
                <small>BLOGS</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('dashboard_home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="<?php echo e(route('user_manage')); ?>">用户管理</a></li>
                <li class="active">添加用户</li>
            </ol>
        </section>
        <section class="content container-fluid">
            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <form role="form" method="POST" action="<?php echo e(route('user_store')); ?>" id="createUserForm">
                        <?php echo csrf_field(); ?>
                        <div class="box box-default">
                            <div class="box-header with-border">
                                <h3 class="box-title">注册用户</h3>
                            </div>
                            <div class="box-body">
                                <div class="form-group <?php echo e($errors->has('roles')?'has-error':''); ?>">
                                    <label for="roles">选择角色</label>
                                    <select class="form-control select2" id="roles" multiple="multiple"
                                            data-placeholder="选择角色"
                                            name="roles[]" style="width: 100%;">
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($role->name); ?>"
                                                    <?php if(in_array($role->name,old('roles',[]))): ?> selected <?php endif; ?>><?php echo e($role->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('roles')): ?>
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i><?php echo e($errors->first('roles')); ?></strong></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('name')?'has-error':''); ?>">
                                    <label for="name">User Name：</label>
                                    <input type="text" class="form-control" name="name" id="name"
                                           value="<?php echo e(old('name')); ?>">
                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i><?php echo e($errors->first('name')); ?></strong></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('email')?'has-error':''); ?>">
                                    <label for="email">Email：</label>
                                    <input type="email" class="form-control" name="email" id="email"
                                           value="<?php echo e(old('email')); ?>">
                                    <span class="help-block text-red">用于找回password，请谨慎填写。</span>
                                    <?php if($errors->has('email')): ?>
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i><?php echo e($errors->first('email')); ?></strong></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('password')?'has-error':''); ?>">
                                    <label for="password">password：</label>
                                    <input type="password" class="form-control" name="password" id="password"
                                           placeholder="Please Enter password">
                                    <?php if($errors->has('password')): ?>
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i><?php echo e($errors->first('password')); ?></strong></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group ">
                                    <label for="password_confirmation">Confirm password：</label>
                                    <input type="password" class="form-control" name="password_confirmation"
                                           id="password_confirmation" placeholder="Please enter password agin">
                                </div>
                                <div class="form-group">
                                    <label>用户Status：</label>
                                    <div class="radio">
                                        <label class="i-checks">
                                            <input type="radio" name="status" value="<?php echo e(\App\Models\User::ACTIVE); ?>"
                                                   <?php if(old( 'status', \App\Models\User::FORBID)==\App\Models\User::ACTIVE ): ?> checked="checked" <?php endif; ?>>
                                            &nbsp; 正常
                                        </label>
                                        <label class="i-checks">
                                            <input type="radio" name="status" value="<?php echo e(\App\Models\User::FORBID); ?>"
                                                   <?php if(old( 'status', \App\Models\User::FORBID)==\App\Models\User::FORBID ): ?> checked="checked" <?php endif; ?>>
                                            &nbsp; 禁用
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="box-footer">
                                <button type="submit" class="btn btn-success btn-flat">提交</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODES2\xtl-blogs\resources\views\admin\permission\user-create.blade.php ENDPATH**/ ?>
