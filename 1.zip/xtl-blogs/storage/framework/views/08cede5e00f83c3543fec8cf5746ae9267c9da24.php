<?php $__env->startSection('title', '文章归档'); ?>
<?php $__env->startSection('keywords', $config['site_keywords']); ?>
<?php $__env->startSection('description', $config['site_description']); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-8">
        <ul class="timeline">
            <?php $__currentLoopData = $archive; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archive_t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="time-label">
                    <span class="bg-black">
                        <?php echo e($archive_t->time); ?>（共<?php echo e($archive_t->posts); ?>篇）
                    </span>
                </li>

                <li>
                    <i class="fa fa-flag bg-blue"></i>

                    <div class="timeline-item">
                            <span class="time">
                                <i class="fa fa-clock-o"></i> <?php echo e($archive_t->time); ?></span>

                        <h3 class="timeline-header"><?php echo e($archive_t->time); ?> 共<?php echo e($archive_t->posts); ?>篇文章</h3>

                        <div class="timeline-body">
                            <ul class="list-group list-group-unbordered">
                                <?php $__currentLoopData = $archive_t->articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item">
                                        <a href="<?php echo e(route('article',$article->id)); ?>" class="title-link"><i
                                                class="fa fa-circle-o"></i>&nbsp;<?php echo e($article->title); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="timeline-footer">
                        </div>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="text-center">
                <?php echo e($archive->links()); ?>

            </div>
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODES2\xtl-blogs\resources\views\home\archive.blade.php ENDPATH**/ ?>