<?php $__env->startSection('title','Console - 站点设置'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>站点设置
                <small>BLOGS</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('dashboard_home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">我的站点</a></li>
                <li class="active">站点设置</li>
            </ol>
        </section>
        <section class="content container-fluid">
            <form role="form" method="POST" action="<?php echo e(route('config_update')); ?>">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="box box-solid">
                            <div class="box-body">
                                <button type="submit" class="btn btn-success btn-flat"><i class="fa fa-check"></i>&nbsp;提交
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="nav-tabs-custom">
                            <ul class="nav nav-tabs">
                                <li class="active"><a href="#tab_1" data-toggle="tab">常规设置</a></li>
                                <li><a href="#tab_2" data-toggle="tab">SEO设置</a></li>
                                <li><a href="#tab_3" data-toggle="tab">功能设置</a></li>
                            </ul>
                            <div class="tab-content">
                                <div class="tab-pane active" id="tab_1">
                                    <div class="form-group <?php echo e($errors->has('site_name')?'has-error':''); ?>">
                                        <label for="site_name">站点名：</label>
                                        <input type="text" class="form-control" name="site_name" id="site_name"
                                               value="<?php echo e($config['site_name']); ?>">
                                        <?php if($errors->has('site_name')): ?>
                                            <span class="help-block "><strong><i
                                                        class="fa fa-times-circle-o"></i><?php echo e($errors->first('site_name')); ?></strong></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('site_status')?'has-error':''); ?>">
                                        <label>网站开启Status：</label>
                                        <div class="radio">
                                            <label class="i-checks">
                                                <input type="radio" name="site_status" value="1"
                                                       <?php if($config[ 'site_status']==1): ?> checked <?php endif; ?>> &nbsp; 开启
                                            </label>
                                            <label class="i-checks">
                                                <input type="radio" name="site_status" value="0"
                                                       <?php if($config[ 'site_status']==0): ?> checked <?php endif; ?>> &nbsp; 关闭
                                            </label>
                                        </div>
                                        <?php if($errors->has('site_status')): ?>
                                            <span class="help-block "><strong><i
                                                        class="fa fa-times-circle-o"></i><?php echo e($errors->first('site_status')); ?></strong></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('site_close_word')?'has-error':''); ?>">
                                        <label for="site_close_word">关站提示文字：</label>
                                        <textarea class="form-control" rows="3" name="site_close_word"
                                                  placeholder="输入 ..."
                                                  style="resize: none;"><?php echo e($config['site_close_word']); ?></textarea>
                                        <?php if($errors->has('site_close_word')): ?>
                                            <span class="help-block "><strong><i
                                                        class="fa fa-times-circle-o"></i><?php echo e($errors->first('site_close_word')); ?></strong></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('site_info')?'has-error':''); ?>">
                                        <label for="">站点通知：</label>
                                        <textarea class="form-control" rows="5" name="site_info" placeholder="输入 ..."
                                                  style="resize: none;"><?php echo e($config['site_info']); ?></textarea>
                                        <?php if($errors->has('site_info')): ?>
                                            <span class="help-block "><strong><i
                                                        class="fa fa-times-circle-o"></i><?php echo e($errors->first('site_info')); ?></strong></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="tab-pane" id="tab_2">
                                    <div class="form-group <?php echo e($errors->has('site_title')?'has-error':''); ?>">
                                        <label for="site_title">网站Title：</label>
                                        <input type="text" class="form-control" name="site_title" id="site_title"
                                               value="<?php echo e($config['site_title']); ?>">
                                        <?php if($errors->has('site_title')): ?>
                                            <span class="help-block "><strong><i
                                                        class="fa fa-times-circle-o"></i><?php echo e($errors->first('site_title')); ?></strong></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('site_keywords')?'has-error':''); ?>">
                                        <label for="site_keywords">网站Keyword：</label>
                                        <input type="text" class="form-control" name="site_keywords" id="site_keywords"
                                               value="<?php echo e($config['site_keywords']); ?>">
                                        <?php if($errors->has('site_keywords')): ?>
                                            <span class="help-block "><strong><i
                                                        class="fa fa-times-circle-o"></i><?php echo e($errors->first('site_keywords')); ?></strong></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('site_description')?'has-error':''); ?>">
                                        <label for="site_description">网站Describe：</label>
                                        <input type="text" class="form-control" name="site_description"
                                               id="site_description" value="<?php echo e($config['site_description']); ?>">
                                        <?php if($errors->has('site_description')): ?>
                                            <span class="help-block "><strong><i
                                                        class="fa fa-times-circle-o"></i><?php echo e($errors->first('site_description')); ?></strong></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="tab-pane" id="tab_3">
                                    <div class="form-group <?php echo e($errors->has('site_allow_comment')?'has-error':''); ?>">
                                        <label>yes否开启文章评论：</label>
                                        <div class="radio">
                                            <label class="i-checks">
                                                <input type="radio" name="site_allow_comment" value="1"
                                                       <?php if($config[ 'site_allow_comment']==1): ?> checked <?php endif; ?>> &nbsp; 开启
                                            </label>
                                            <label class="i-checks">
                                                <input type="radio" name="site_allow_comment" value="0"
                                                       <?php if($config[ 'site_allow_comment']==0): ?> checked <?php endif; ?>> &nbsp; 关闭
                                            </label>
                                        </div>
                                        <?php if($errors->has('site_allow_comment')): ?>
                                            <span class="help-block "><strong><i
                                                        class="fa fa-times-circle-o"></i><?php echo e($errors->first('site_allow_comment')); ?></strong></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('site_allow_message')?'has-error':''); ?>">
                                        <label>yes否开启站点留言：</label>
                                        <div class="radio">
                                            <label class="i-checks">
                                                <input type="radio" name="site_allow_message" value="1"
                                                       <?php if($config[ 'site_allow_message']==1): ?> checked <?php endif; ?>> &nbsp; 开启
                                            </label>
                                            <label class="i-checks">
                                                <input type="radio" name="site_allow_message" value="0"
                                                       <?php if($config[ 'site_allow_message']==0): ?> checked <?php endif; ?>> &nbsp; 关闭
                                            </label>
                                        </div>
                                        <?php if($errors->has('site_allow_message')): ?>
                                            <span class="help-block "><strong><i
                                                        class="fa fa-times-circle-o"></i><?php echo e($errors->first('site_allow_message')); ?></strong></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('site_allow_subscribe')?'has-error':''); ?>">
                                        <label>yes否开启站点订阅：</label>
                                        <div class="radio">
                                            <label class="i-checks">
                                                <input type="radio" name="site_allow_subscribe" value="1"
                                                       <?php if($config[ 'site_allow_subscribe']==1): ?> checked <?php endif; ?>> &nbsp;
                                                开启
                                            </label>
                                            <label class="i-checks">
                                                <input type="radio" name="site_allow_subscribe" value="0"
                                                       <?php if($config[ 'site_allow_subscribe']==0): ?> checked <?php endif; ?>> &nbsp;
                                                关闭
                                            </label>
                                        </div>
                                        <?php if($errors->has('site_allow_subscribe')): ?>
                                            <span class="help-block "><strong><i
                                                        class="fa fa-times-circle-o"></i><?php echo e($errors->first('site_allow_subscribe')); ?></strong></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('allow_reward')?'has-error':''); ?>">
                                        <label>yes否开启文章打赏：</label>
                                        <div class="radio">
                                            <label class="i-checks">
                                                <input type="radio" name="allow_reward" value="1"
                                                       <?php if($config[ 'allow_reward']==1): ?> checked <?php endif; ?>> &nbsp; 开启
                                            </label>
                                            <label class="i-checks">
                                                <input type="radio" name="allow_reward" value="0"
                                                       <?php if($config[ 'allow_reward']==0): ?> checked <?php endif; ?>> &nbsp; 关闭
                                            </label>
                                        </div>
                                        <?php if($errors->has('allow_reward')): ?>
                                            <span class="help-block "><strong><i
                                                        class="fa fa-times-circle-o"></i><?php echo e($errors->first('allow_reward')); ?></strong></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('alipay')?'has-error':''); ?>">
                                        <label for="alipay">支付宝打赏二维码地址：</label>
                                        <input type="text" class="form-control" name="alipay" id="alipay"
                                               value="<?php echo e($config['alipay']); ?>">
                                        <?php if($errors->has('alipay')): ?>
                                            <span class="help-block "><strong><i
                                                        class="fa fa-times-circle-o"></i><?php echo e($errors->first('alipay')); ?></strong></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('wepay')?'has-error':''); ?>">
                                        <label for="site_title">微信打赏二维码地址：</label>
                                        <input type="text" class="form-control" name="wepay" id="wepay"
                                               value="<?php echo e($config['wepay']); ?>">
                                        <?php if($errors->has('wepay')): ?>
                                            <span class="help-block "><strong><i
                                                        class="fa fa-times-circle-o"></i><?php echo e($errors->first('wepay')); ?></strong></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="nav-tabs-custom">
                            <ul class="nav nav-tabs">
                                <li class="active"><a href="#tab_4" data-toggle="tab">站长设置</a></li>
                                <li><a href="#tab_5" data-toggle="tab">备案设置</a></li>
                                <li><a href="#tab_6" data-toggle="tab">其它设置</a></li>
                            </ul>
                            <div class="tab-content">
                                <div class="tab-pane active" id="tab_4">
                                    <div class="form-group <?php echo e($errors->has('site_admin')?'has-error':''); ?>">
                                        <label for="site_admin">站长名称：</label>
                                        <input type="text" class="form-control" name="site_admin" id="site_admin"
                                               value="<?php echo e($config['site_admin']); ?>"> <?php if($errors->has('site_admin')): ?>
                                            <span class="help-block ">
                                        <strong><i
                                                class="fa fa-times-circle-o"></i><?php echo e($errors->first('site_admin')); ?></strong>
                                    </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('site_admin_avatar')?'has-error':''); ?>">
                                        <label for="site_admin_avatar">站长头像：</label>
                                        <input type="text" class="form-control" name="site_admin_avatar"
                                               id="site_admin_avatar"
                                               value="<?php echo e($config['site_admin_avatar']); ?>"> <?php if($errors->has('site_admin_avatar')): ?>
                                            <span class="help-block ">
                                        <strong><i
                                                class="fa fa-times-circle-o"></i><?php echo e($errors->first('site_admin_avatar')); ?></strong>
                                    </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('site_admin_info')?'has-error':''); ?>">
                                        <label for="site_admin_info">站长个人介绍：</label>
                                        <input type="text" class="form-control" name="site_admin_info"
                                               id="site_admin_info"
                                               value="<?php echo e($config['site_admin_info']); ?>"> <?php if($errors->has('site_admin_info')): ?>
                                            <span class="help-block ">
                                        <strong><i
                                                class="fa fa-times-circle-o"></i><?php echo e($errors->first('site_admin_info')); ?></strong>
                                    </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('site_mailto_admin')?'has-error':''); ?>">
                                        <label for="site_mailto_admin">站长Email：</label>
                                        <input type="text" class="form-control" name="site_mailto_admin"
                                               id="site_mailto_admin"
                                               value="<?php echo e($config['site_mailto_admin']); ?>"> <?php if($errors->has('site_mailto_admin')): ?>
                                            <span class="help-block ">
                                        <strong><i
                                                class="fa fa-times-circle-o"></i><?php echo e($errors->first('site_mailto_admin')); ?></strong>
                                    </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('site_admin_mail')?'has-error':''); ?>">
                                        <label for="site_admin_mail">站长Email投稿地址：</label>
                                        <input type="text" class="form-control" name="site_admin_mail"
                                               id="site_admin_mail"
                                               value="<?php echo e($config['site_admin_mail']); ?>"> <?php if($errors->has('site_admin_mail')): ?>
                                            <span class="help-block ">
                                        <strong><i
                                                class="fa fa-times-circle-o"></i><?php echo e($errors->first('site_admin_mail')); ?></strong>
                                    </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('site_admin_weibo')?'has-error':''); ?>">
                                        <label for="site_admin_weibo">微博地址：</label>
                                        <input type="text" class="form-control" name="site_admin_weibo"
                                               id="site_admin_weibo"
                                               value="<?php echo e($config['site_admin_weibo']); ?>"> <?php if($errors->has('site_admin_weibo')): ?>
                                            <span class="help-block ">
                                        <strong><i
                                                class="fa fa-times-circle-o"></i><?php echo e($errors->first('site_admin_weibo')); ?></strong>
                                    </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('site_admin_github')?'has-error':''); ?>">
                                        <label for="site_admin_github">GitHub地址：</label>
                                        <input type="text" class="form-control" name="site_admin_github"
                                               id="site_admin_github"
                                               value="<?php echo e($config['site_admin_github']); ?>"> <?php if($errors->has('site_admin_github')): ?>
                                            <span class="help-block ">
                                        <strong><i
                                                class="fa fa-times-circle-o"></i><?php echo e($errors->first('site_admin_github')); ?></strong>
                                    </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="tab-pane" id="tab_5">
                                    <div class="form-group <?php echo e($errors->has('site_icp_num')?'has-error':''); ?>">
                                        <label for="site_icp_num">网站备案号：</label>
                                        <input type="text" class="form-control" name="site_icp_num" id="site_icp_num"
                                               value="<?php echo e($config['site_icp_num']); ?>">
                                        <?php if($errors->has('site_icp_num')): ?>
                                            <span class="help-block "><strong><i
                                                        class="fa fa-times-circle-o"></i><?php echo e($errors->first('site_icp_num')); ?></strong></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('site_110beian_num')?'has-error':''); ?>">
                                        <label for="site_110beian_num">公安网站备案号：</label>
                                        <input type="text" class="form-control" name="site_110beian_num"
                                               id="site_110beian_num" value="<?php echo e($config['site_110beian_num']); ?>">
                                        <?php if($errors->has('site_110beian_num')): ?>
                                            <span class="help-block "><strong><i
                                                        class="fa fa-times-circle-o"></i><?php echo e($errors->first('site_110beian_num')); ?></strong></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group <?php echo e($errors->has('site_110beian_link')?'has-error':''); ?>">
                                        <label for="site_110beian_link">公安网站备案链接：</label>
                                        <input type="text" class="form-control" name="site_110beian_link"
                                               id="site_110beian_link" value="<?php echo e($config['site_110beian_link']); ?>">
                                        <?php if($errors->has('site_110beian_link')): ?>
                                            <span class="help-block "><strong><i
                                                        class="fa fa-times-circle-o"></i><?php echo e($errors->first('site_110beian_link')); ?></strong></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="tab-pane" id="tab_6">
                                    <div class="form-group <?php echo e($errors->has('water_mark_status')?'has-error':''); ?>">
                                        <label>开启图片水印：</label>
                                        <div class="radio">
                                            <label class="i-checks">
                                                <input type="radio" name="water_mark_status" value="1"
                                                       <?php if($config[ 'water_mark_status']==1): ?> checked <?php endif; ?>> &nbsp; 开启
                                            </label>
                                            <label class="i-checks">
                                                <input type="radio" name="water_mark_status" value="0"
                                                       <?php if($config[ 'water_mark_status']==0): ?> checked <?php endif; ?>> &nbsp; 关闭
                                            </label>
                                        </div>
                                        <?php if($errors->has('water_mark_status')): ?>
                                            <span class="help-block "><strong><i
                                                        class="fa fa-times-circle-o"></i><?php echo e($errors->first('water_mark_status')); ?></strong></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label>上传水印(Default图片右下角)：</label>
                                        <div class="water-mark">
                                            <a data-toggle="modal" href='#water-mark-modal'>
                                                <img class="img-responsive" src="<?php echo e(asset('img/water_mark.png')); ?>"
                                                     width="100" height="100"/>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            <div class="modal fade" id="water-mark-modal">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            <h4 class="modal-title">上传水印</h4>
                        </div>
                        <form action="<?php echo e(route('water_mark_upload')); ?>" method="post" enctype="multipart/form-data">
                            <div class="modal-body">
                                <?php echo csrf_field(); ?>
                                <input type="file" name="water_mark" class="dropify" data-max-height="200"
                                       data-allowed-file-extensions="png jpg jpeg" data-max-file-size="1M"/>
                                <span class="help-block">水印支持png、jpg、jepg 格式小于1M的图片.为保证头像质量请上传等比例的图片。并保证宽度小于200像素</span>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary btn-flat">上传</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODES2\xtl-blogs\resources\views\admin\config.blade.php ENDPATH**/ ?>
