<?php $__env->startSection('title','Console - 角色管理'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>角色管理
                <small>BLOGS</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('dashboard_home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">权限管理</a></li>
                <li class="active">角色管理</li>
            </ol>
        </section>
        <section class="content container-fluid">
            <div class="row">
                <div class="col-md-4">
                    <div class="box">
                        <div class="box-header">
                            <h3 class="box-title">全部角色</h3>
                            <span>共 <?php echo e($roles->total()); ?>个</span>
                            <form action="<?php echo e(route('role_search')); ?>" method="get" style="display: inline-flex"
                                  class="pull-right">
                                <div class="box-tools">
                                    <div class="input-group input-group-sm" style="width: 150px;">
                                        <input type="text" name="keyword" class="form-control" placeholder="Search ">

                                        <span class="input-group-btn">
                                            <button type="submit" class="btn btn-default"><i
                                                    class="fa fa-search"></i></button>
                                        </span>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="box-body table-responsive no-padding">
                            <table class="table table-hover">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>角色名</th>
                                    <th>Operate</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if(!blank($roles)): ?>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><input type="checkbox" value="<?php echo e($role->id); ?>" name="rid"
                                                       class="i-checks"></td>
                                            <td><?php echo e($role->name); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('role_edit',$role->id)); ?>" class="text-green">
                                                    <i class="fa fa-pencil-square-o"></i>
                                                </a>&nbsp;&nbsp;&nbsp;
                                                <a href="javascript:void(0)" class="text-red delRole">
                                                    <i class="fa fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td valign="top" colspan="3">表中数据为空</td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                            <form id="deleteForm" style="display: none;" action="<?php echo e(route('role_destroy')); ?>"
                                  method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="rid" id="deleteId">
                            </form>
                        </div>
                        <div class="box-footer clearfix">
                            <div class="pull-left">
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectAll('rid')">Select All</a>
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectEmpty('rid')">Deselect All</a>
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectReverse('rid')">Invert</a>
                                <a href="javascript:void(0)" class="btn btn-danger btn-flat"
                                   id="delSelectedRole">Delete Selected</a>
                            </div>
                            <?php if(request()->has('keyword')): ?>
                                <?php echo e($roles->appends(['keyword' => request()->input('keyword')])->links('vendor.pagination.adminlte')); ?>

                            <?php else: ?>
                                <?php echo e($roles->links('vendor.pagination.adminlte')); ?>

                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                    <form role="form" method="POST" action="<?php echo e(route('role_store')); ?>" id="createRoleForm">
                        <?php echo csrf_field(); ?>
                        <div class="box box-default">
                            <div class="box-header with-border">
                                <h3 class="box-title">新建角色</h3>
                            </div>
                            <div class="box-body">
                                <div class="form-group <?php echo e($errors->has('name')?'has-error':''); ?>">
                                    <label for="name">角色名：</label>
                                    <input type="text" class="form-control" name="name" id="name" placeholder="Please Enter 角色名称"
                                           value="<?php echo e(old('name')); ?>">
                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i><?php echo e($errors->first('name')); ?></strong></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="permissions">权限：</label>
                                    <div class="checkbox">
                                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <label><input type="checkbox" class="i-checks" value="<?php echo e($permission->name); ?>"
                                                          name="permissions[]"
                                                          <?php if(in_array($permission->name, old('permissions', []))): ?> checked="checked" <?php endif; ?>>&nbsp;<?php echo e($permission->name); ?>

                                            </label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="box-footer">
                                <button type="submit" class="btn btn-success btn-flat">提交</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODES2\xtl-blogs\resources\views\admin\permission\role.blade.php ENDPATH**/ ?>
