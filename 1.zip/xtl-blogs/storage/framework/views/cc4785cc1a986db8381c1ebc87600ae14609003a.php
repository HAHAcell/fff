<?php $__env->startSection('title','Console - 评论管理'); ?>
<?php $__env->startSection('css'); ?>
    <script>
        var showCommentUrl = "<?php echo e(route('comment_show')); ?>"
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>评论管理
                <small>BLOGS</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('dashboard_home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">Content Manage</a></li>
                <li class="active">评论管理</li>
            </ol>
        </section>
        <section class="content container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="box">
                        <div class="box-header with-border">
                            <h3 class="box-title">全部评论</h3>
                            <span>共<?php echo e($comments->total()); ?>个</span>
                        </div>
                        <div class="box-body table-responsive no-padding">
                            <table class="table table-hover">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>文章</th>
                                    <th>昵称</th>
                                    <th>Email</th>
                                    <th>Content</th>
                                    <th>Time</th>
                                    <th>Status</th>
                                    <th>Operate</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if(!blank($comments)): ?>
                                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><input type="checkbox" value="<?php echo e($comment->id); ?>" name="cid"
                                                       class="i-checks"></td>
                                            <td><?php echo e($comment->article->title); ?></td>
                                            <td><?php echo e($comment->nickname); ?></td>
                                            <td><?php echo e($comment->email); ?></td>
                                            <td><?php echo e(\App\Helpers\Extensions\Tool::subStr($comment->content, 0, 20, true)); ?></td>
                                            <td><?php echo e($comment->created_at); ?></td>
                                            <td><?php echo $comment->status_tag; ?></td>
                                            <td>
                                                <a href="javascript:void(0)" class="text-green showComment">
                                                    查看
                                                </a>&nbsp;&nbsp;
                                                <a href="javascript:void(0)" class="text-red delComment">
                                                    <i class="fa fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td valign="top" colspan="8">表中数据为空</td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>

                            </table>
                            <form id="deleteForm" style="display: none;" method="POST"
                                  action="<?php echo e(route('comment_destroy')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="cid" id="deleteId">
                            </form>
                            <form id="checkForm" style="display: none;" method="POST"
                                  action="<?php echo e(route('comment_check')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="cid" id="checkId">
                            </form>
                        </div>
                        <div class="box-footer clearfix">
                            <div class="pull-left">
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectAll('cid')">Select All</a>
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectEmpty('cid')">Deselect All</a>
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectReverse('cid')">Invert</a>
                                <a href="javascript:void(0)" class="btn btn-danger btn-flat" id="delSelectedComment">Delete Selected</a>
                                <a href="javascript:void(0)" class="btn btn-success btn-flat" id="checkSelectedComment">通过/Hide</a>
                            </div>
                            <?php echo e($comments->links('vendor.pagination.adminlte')); ?>

                        </div>
                        <div class="modal fade" id="commentModal" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <form class="form-horizontal" role="form" method="POST"
                                          action="<?php echo e(route('comment_reply')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" id="cid">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                                &times;
                                            </button>
                                            <h4 class="modal-title">评论审核</h4>
                                        </div>
                                        <div class="modal-body">
                                            <div class="form-group">
                                                <label class="col-sm-2 control-label">昵称</label>
                                                <div class="col-sm-10">
                                                    <p class="form-control-static" id="nickname"></p>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-2 control-label">Email</label>
                                                <div class="col-sm-10">
                                                    <p class="form-control-static" id="email"></p>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-2 control-label">Content</label>
                                                <div class="col-sm-10">
                                                    <p class="form-control-static" id="content"></p>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-2 control-label">Time</label>
                                                <div class="col-sm-10">
                                                    <p class="form-control-static" id="created_at"></p>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-sm-2 control-label" for="reply">回复</label>
                                                <div class="col-sm-10">
                                                    <textarea class="form-control" style="resize: none;" rows="3"
                                                              cols="4" name="reply" id="reply"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-primary btn-flat">回复</button>
                                            <button type="button" class="checkComment btn btn-success btn-flat">通过/Hide
                                            </button>
                                            <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">
                                                关闭
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODES2\xtl-blogs\resources\views\admin\comment.blade.php ENDPATH**/ ?>
