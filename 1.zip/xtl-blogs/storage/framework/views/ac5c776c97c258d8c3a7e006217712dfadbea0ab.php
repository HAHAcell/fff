<?php $__env->startSection('title','Console - 文章回收站'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>回收站
                <small>BLOGS</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('dashboard_home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="<?php echo e(route('article_manage')); ?>">Article Manage</a></li>
                <li class="active">文章回收站</li>
            </ol>
        </section>
        <section class="content container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="box">
                        <div class="box-header with-border">
                            <h3 class="box-title">文章回收站</h3>
                            <span>共 <?php echo e($articles->total()); ?>篇</span>
                        </div>
                        <div class="box-body table-responsive no-padding">
                            <table class="table table-hover">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Title</th>
                                    <th>删除Time</th>
                                    <th>Operate</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if(!blank($articles)): ?>
                                    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><input type="checkbox" value="<?php echo e($article->id); ?>" name="aid"
                                                       class="i-checks"></td>
                                            <td><?php echo e($article->title); ?></td>
                                            <td><?php echo e($article->deleted_at); ?></td>
                                            <td>
                                                <a class="text-green restoreArticle"><i class="fa fa-recycle"></i></a>&nbsp;&nbsp;
                                                <a class="text-red destroyArticle"><i class="fa fa-trash"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td valign="top" colspan="4">表中数据为空</td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                            <form id="restoreForm" style="display: none;" method="POST"
                                  action="<?php echo e(route('article_restore')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="aid" id="restoreId">
                            </form>
                            <form id="destroyForm" style="display: none;" method="POST"
                                  action="<?php echo e(route('article_destroy')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="aid" id="destroyId">
                            </form>
                        </div>
                        <div class="box-footer clearfix">
                            <div class="pull-left">
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectAll('aid')">Select All</a>
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectEmpty('aid')">Deselect All</a>
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectReverse('aid')">Invert</a>
                                <a href="javascript:void(0)" class="btn btn-danger btn-flat"
                                   id="destroySelectedArticle">彻底Delete Selected</a>
                                <a href="javascript:void(0)" class="btn btn-success btn-flat"
                                   id="restoreSelectedArticle">恢复选定</a>
                            </div>
                            <?php echo e($articles->links('vendor.pagination.adminlte')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODES2\xtl-blogs\resources\views\admin\article-trash.blade.php ENDPATH**/ ?>
