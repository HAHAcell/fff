<?php $__env->startSection('title', $config['site_title']); ?>
<?php $__env->startSection('keywords', $config['site_keywords']); ?>
<?php $__env->startSection('description', $config['site_description']); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-8">
<!--        <div class="box box-default">
            <div class="box-header with-border">
                <i class="fa fa-bullhorn"></i>

                <h3 class="box-title">网站公告</h3>
            </div>
            <div class="box-body">
                <p><?php echo e($config['site_info']); ?></p>
            </div>
        </div>-->
        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="box box-solid">
                <div class="box-body article-body">

                    <a href="<?php echo e(route('article',$article->id)); ?>" class="title-link">
                        <h3>
                            <?php if($article->is_top): ?>
                                🔥&nbsp;
                            <?php endif; ?>
                            <?php echo e($article->title); ?>

                        </h3>
                    </a>
                    <div class="small m-b-xs">
                        <strong><?php echo e($article->author); ?></strong>&nbsp;&nbsp;<span class="text-muted"><i
                                class="fa fa-clock-o"></i>&nbsp;Last updated on&nbsp;<?php echo e(\App\Helpers\Extensions\Tool::transformTime($article->feed_updated_at)); ?></span>
                    </div>
                    <div class="description">
                        <p style="word-wrap:break-word;"><?php echo e($article->description); ?></p>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <h5>Label：</h5>
                            <?php $__currentLoopData = $article->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('tag',$tag->id)); ?>"
                                   <?php switch(($tag->id)%5): case (0): ?>class="tag btn btn-flat btn-xs bg-black"
                                   <?php break; ?> <?php case (1): ?>class="tag btn btn-flat btn-xs bg-olive"
                                   <?php break; ?> <?php case (2): ?>class="tag btn btn-flat btn-xs bg-blue"
                                   <?php break; ?> <?php case (3): ?>class="tag btn btn-flat btn-xs bg-purple"
                                   <?php break; ?> <?php default: ?> class="tag btn btn-flat btn-xs bg-maroon" <?php endswitch; ?>><i
                                        class="fa fa-tag"></i>&nbsp;<?php echo e($tag->name); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="col-md-6">
                            <div class="small text-right">
                                <h5>Status：</h5>
                                <div><i class="fa fa-comments-o"> </i> <?php echo e($article->comment_count); ?> 评论</div>
                                <i class="fa fa-eye"> </i> <?php echo e($article->click); ?> browse
                            </div>
                        </div>
                    </div>
                    <div class="hr-line-dashed"></div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="pull-right">
                                <a href="<?php echo e(route('article',$article->id)); ?>" class="btn btn-flat bg-black tag"><i
                                        class="fa fa-eye"></i> More</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($articles->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODES2\xtl-blogs\resources\views\home\index.blade.php ENDPATH**/ ?>
