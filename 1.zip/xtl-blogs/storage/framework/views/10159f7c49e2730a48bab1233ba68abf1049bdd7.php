<!-- 所有的错误提示 -->
<?php if(count($errors)): ?>
    <div class="box box-danger">
        <div class="box-body">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p class="text-danger">
                    <i class='fa fa-times-circle'></i> <?php echo e($error); ?>

                </p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php endif; ?>

<?php /**PATH D:\CODES2\xtl-blogs\resources\views\errors\validator.blade.php ENDPATH**/ ?>