<?php $__env->startSection('title','Console - 菜单管理'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>菜单管理
                <small>BLOGS</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(route('dashboard_home')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">Content Manage</a></li>
                <li class="active">菜单管理</li>
            </ol>
        </section>
        <section class="content container-fluid">
            <div class="row">
                <div class="col-md-8">
                    <div class="box">
                        <div class="box-header with-border">
                            <h3 class="box-title">全部菜单</h3>
                        </div>
                        <div class="box-body table-responsive no-padding">
                            <table class="table table-hover">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>菜单名</th>
                                    <th>类型</th>
                                    <th>排序权重</th>
                                    <th>Status</th>
                                    <th>Operate</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if(!blank($navs)): ?>
                                    <?php $__currentLoopData = $navs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><label><input type="checkbox" value="<?php echo e($nav->id); ?>" name="nid"
                                                              class="i-checks"></label></td>
                                            <td><?php echo $nav->name; ?></td>
                                            <td>
                                                <?php echo e($nav->type_name); ?>

                                            </td>
                                            <td>
                                                <?php echo e($nav->sort); ?>

                                            </td>
                                            <td>
                                                <?php echo $nav->status_tag; ?>

                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('nav_edit',$nav->id)); ?>" class="text-green">
                                                    <i class="fa fa-pencil-square-o"></i>
                                                </a>&nbsp;&nbsp;
                                                <a href="javascript:void(0)" class="text-red delNav">
                                                    <i class="fa fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td valign="top" colspan="6">表中数据为空</td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                            <form id="deleteForm" style="display: none;" action="<?php echo e(route('nav_destroy')); ?>"
                                  method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="nid" id="deleteId">
                            </form>
                        </div>
                        <div class="box-footer clearfix">
                            <div class="pull-left">
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectAll('nid')">Select All</a>
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectEmpty('nid')">Deselect All</a>
                                <a href="javascript:void(0)" class="btn btn-primary btn-flat"
                                   onclick="selectReverse('nid')">Invert</a>
                                <a href="javascript:void(0)" class="btn btn-danger btn-flat"
                                   id="delSelectedNav">Delete Selected</a>
                            </div>
                        </div>
                    </div>
                    <div class="box box-solid">
                        <div class="box-body table-responsive no-padding">
                            <table class="table table-hover">
                                <tr>
                                    <th>#</th>
                                    <th>固有菜单名</th>
                                    <th>链接</th>
                                </tr>
                                <tr>
                                    <th>#</th>
                                    <td>Home</td>
                                    <td><?php echo e(route('home')); ?></td>
                                </tr>
                                <tr>
                                    <th>#</th>
                                    <td>归档</td>
                                    <td><?php echo e(route('archive')); ?></td>
                                </tr>
                                <tr>
                                    <th>#</th>
                                    <td>留言</td>
                                    <td><?php echo e(route('message')); ?> <?php if($config['site_allow_message'] == 0): ?>
                                            (此功能配置已关闭)<?php endif; ?></td>
                                </tr>
                                <tr>
                                    <th>#</th>
                                    <td>订阅</td>
                                    <td><?php echo e(route('subscribe')); ?> <?php if($config['site_allow_subscribe'] == 0): ?>
                                            (此功能配置已关闭)<?php endif; ?></td>
                                </tr>
                                <tr>
                                    <th>#</th>
                                    <td>友链</td>
                                    <td><?php echo e(route('link')); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <form role="form" method="POST" action="<?php echo e(route('nav_store')); ?>" id="createNavForm">
                        <?php echo csrf_field(); ?>
                        <div class="box box-default">
                            <div class="box-header with-border">
                                <h3 class="box-title">新建菜单</h3>
                            </div>
                            <div class="box-body">
                                <div class="form-group <?php echo e($errors->has('type')?'has-error':''); ?>">
                                    <label for="type">菜单类型：</label>
                                    <select class="form-control select2" name="type" id="type">
                                        <option value="">菜单类型</option>
                                        <?php $__currentLoopData = \App\Models\Nav::TYPE; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"
                                                    <?php if(old('type') == $key): ?> selected="selected"<?php endif; ?>><?php echo e($type); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('type')): ?>
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i><?php echo e($errors->first('type')); ?></strong></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('parent_id')?'has-error':''); ?>">
                                    <label for="parent_id">父级菜单</label>
                                    <select class="form-control select2" name="parent_id" id="parent_id">
                                        <option value="">Please choose 菜单</option>
                                        <option value="0" selected="selected">一级菜单</option>
                                        <?php $__currentLoopData = $emptyNavs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empty_nav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($empty_nav->id); ?>"
                                                    <?php if(old('parent_id') == $empty_nav->id): ?> selected="selected"<?php endif; ?>><?php echo e($empty_nav->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <span class="help-block">仅可选空菜单类型，Default为1级菜单</span>
                                    <?php if($errors->has('parent_id')): ?>
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i><?php echo e($errors->first('parent_id')); ?></strong></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('name')?'has-error':''); ?>">
                                    <label for="name">菜单名：</label>
                                    <input type="text" class="form-control" name="name" id="name" placeholder="Please Enter 菜单名称"
                                           value="<?php echo e(old('name')); ?>">
                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i><?php echo e($errors->first('name')); ?></strong></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('url')?'has-error':''); ?>" id="url-group">
                                    <label for="url">链接：</label>
                                    <input type="text" class="form-control" name="url" id="url" placeholder="Please Enter 链接"
                                           value="<?php echo e(old('url')); ?>">
                                    <span class="help-block text-red">仅对链接菜单有效，链接前请加上协议(如:https://xxx.com)</span>
                                    <?php if($errors->has('url')): ?>
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i><?php echo e($errors->first('url')); ?></strong></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('sort')?'has-error':''); ?>">
                                    <label for="sort">排序权重：</label>
                                    <input type="text" class="form-control" name="sort" id="sort"
                                           placeholder="Please Enter 数字，Default为1" value="<?php echo e(old('sort')); ?>">
                                    <?php if($errors->has('sort')): ?>
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i><?php echo e($errors->first('sort')); ?></strong></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group <?php echo e($errors->has('status')?'has-error':''); ?>">
                                    <label>Status：</label>
                                    <div class="radio">
                                        <label class="i-checks">
                                            <input type="radio" name="status"
                                                   value="<?php echo e(\App\Models\Nav::STATUS_DISPLAY); ?>"
                                                   <?php if(old( 'status', \App\Models\Nav::STATUS_DISPLAY)==\App\Models\Nav::STATUS_DISPLAY ): ?> checked="checked" <?php endif; ?>>
                                            &nbsp;Show
                                        </label>
                                        <label class="i-checks">
                                            <input type="radio" name="status" value="<?php echo e(\App\Models\Nav::STATUS_HIDE); ?>"
                                                   <?php if(old( 'status', \App\Models\Nav::STATUS_HIDE)==\App\Models\Nav::STATUS_HIDE ): ?> checked="checked" <?php endif; ?>>
                                            &nbsp;Hide
                                        </label>
                                    </div>
                                    <?php if($errors->has('status')): ?>
                                        <span class="help-block "><strong><i
                                                    class="fa fa-times-circle-o"></i><?php echo e($errors->first('status')); ?></strong></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="box-footer">
                                <button type="submit" class="btn btn-success btn-flat">提交</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(function () {
            let type_empty = "<?php echo e(\App\Models\Nav::TYPE_EMPTY); ?>";
            let type_menu = "<?php echo e(\App\Models\Nav::TYPE_MENU); ?>";
            let type_page = "<?php echo e(\App\Models\Nav::TYPE_PAGE); ?>";
            let type_archive = "<?php echo e(\App\Models\Nav::TYPE_ARCHIVE); ?>";
            $("#type").select2();
            let parent_id_select = $('#parent_id').select2();
            $("#type").on("change", function () {
                let type = $(this).val();
                if (type_empty == type || type_menu == type) {
                    parent_id_select.val("0").trigger("change");
                    $("#url-group").attr("style", "display:none");
                    $("#parent_id").attr("disabled", "disabled");
                } else if (type_page == type) {
                    $("#url").attr("placeholder", "Please Enter 单页链接，或单页ID");
                    $("#url-group").removeAttr("style");
                    $("#parent_id").removeAttr("disabled");
                } else if (type_archive == type) {
                    $("#url-group").attr("style", "display:none");
                    $("#parent_id").removeAttr("disabled");
                } else {
                    $("#url-group").removeAttr("style");
                    $("#parent_id").removeAttr("disabled");
                }
            });
            $("#createNavForm").on("submit", function () {
                $("#parent_id").removeAttr("disabled");
            })

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\CODES2\xtl-blogs\resources\views\admin\nav.blade.php ENDPATH**/ ?>
