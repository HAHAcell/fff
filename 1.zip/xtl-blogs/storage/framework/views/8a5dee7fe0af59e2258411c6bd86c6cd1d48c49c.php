<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="keywords" content="<?php echo $__env->yieldContent('keywords'); ?>"/>
    <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>"/>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/ionicons@4/dist/css/ionicons.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@2/dist/css/AdminLTE.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@2/dist/css/skins/_all-skins.min.css">
    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/node-pace-progress@1/themes/white/pace-theme-flash.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@7/dist/sweetalert2.min.css">
    <link href="<?php echo e(asset('css/frontend.custom.css')); ?>" rel="stylesheet">
<?php echo $__env->yieldContent('css'); ?>

<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.3/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body class="hold-transition skin-black layout-top-nav">
<div class="wrapper">
    <header class="main-header">
        <nav class="navbar navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">
                    <a href="<?php echo e(route('home')); ?>" class="navbar-brand">
                        <b><?php echo e($config['site_name']); ?></b></a>
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                            data-target="#navbar-collapse">
                        <i class="fa fa-bars"></i>
                    </button>
                </div>
                <div class="collapse navbar-collapse " id="navbar-collapse">
<!--                    <form class="navbar-form navbar-left" role="search" action="<?php echo e(route('search')); ?>" method="get">
                        <div class="form-group">
                            <input type="text" class="form-control" id="navbar-search-input" name="keyword"
                                   placeholder="Search ">
                        </div>
                    </form>
                    <ul class="nav navbar-nav">
                        <?php $__currentLoopData = $nav_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nav_v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($nav_v->type === \App\Models\Nav::TYPE_MENU): ?>
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"> <?php echo e($nav_v->name); ?>

                                        <span class="caret"></span>
                                    </a>
                                    <ul class="dropdown-menu" role="menu">
                                        <?php $__currentLoopData = $category_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category_v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <a href="<?php echo e(route('category',$category_v->id)); ?>"><?php echo e($category_v->name); ?></a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </li>
                            <?php elseif($nav_v->type === \App\Models\Nav::TYPE_ARCHIVE): ?>
                                <li>
                                    <a href="<?php echo e(route('archive')); ?>"><?php echo e($nav_v->name); ?></a>
                                </li>
                            <?php elseif($nav_v->type === \App\Models\Nav::TYPE_EMPTY): ?>
                                <?php if(!blank($nav_v->children)): ?>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo e($nav_v->name); ?>

                                            <span class="caret"></span>
                                        </a>
                                        <ul class="dropdown-menu" role="menu">
                                            <?php $__currentLoopData = $nav_v->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nav_son): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <a href="<?php echo e($nav_son->url); ?>"><?php echo e($nav_son->name); ?></a>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </li>
                                <?php else: ?>
                                    <li>
                                        <a href="<?php echo e($nav_v->url); ?>"><?php echo e($nav_v->name); ?></a>
                                    </li>
                                <?php endif; ?>
                            <?php elseif($nav_v->type === \App\Models\Nav::TYPE_PAGE || \App\Models\Nav::TYPE_LINK): ?>
                                <li class="">
                                    <a href="<?php echo e($nav_v->url); ?>"><?php echo e($nav_v->name); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>-->
                </div>
            </div>
        </nav>
    </header>
    <div class="blank-div"></div>
    <div class="content-wrapper">
        <div class="container" id="main">
            <section class="content">
                <div class="row">
                    <?php echo $__env->yieldContent('content'); ?>
                    <div class="col-md-4 hidden-xs">
                        <div class="row">
                            <div class="box box-widget widget-user">
                                <div class="widget-user-header  bg-black">
                                    <h3 class="widget-user-username"><?php echo e($config['site_admin']); ?></h3>
                                    <h5 class="widget-user-desc"><?php echo e($config['site_admin_info']); ?></h5>
                                </div>
                                <div class="widget-user-image">
                                    <img class="img-circle" src="<?php echo e($config['site_admin_avatar']); ?>"
                                         alt="<?php echo e($config['site_admin']); ?>">
                                </div>
                                <div class="box-footer">
                                    <div class="row">
<!--                                        <div class="col-sm-4 border-right">
                                            <div class="description-block">
                                                <h5 class="description-header"><i
                                                        class="fa fa-github-alt"></i></h5>
                                                <span class="description-text"><a class=""
                                                                                  href="<?php echo e($config['site_admin_github']); ?>">仓库</a></span>
                                            </div>
                                        </div>
                                        <div class="col-sm-4 border-right">
                                            <div class="description-block">
                                                <h5 class="description-header"><i
                                                        class="fa fa-weibo"></i></h5>
                                                <span class="description-text"><a class=""
                                                                                  href="<?php echo e($config['site_admin_weibo']); ?>">微博</a></span>
                                            </div>
                                        </div>
                                        <div class="col-sm-4">
                                            <div class="description-block">
                                                <h5 class="description-header"><i class="fa fa-envelope"></i></h5>
                                                <span class="description-text"><a class=""
                                                                                  href="<?php echo e($config['site_admin_mail']); ?>">Email</a></span>
                                            </div>
                                        </div>-->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="box box-solid">
                                <div class="box-header with-border">
                                    <i class="fa fa-arrow-up"></i>

                                    <h3 class="box-title">Hot Articles</h3>
                                </div>
                                <div class="box-body">
                                    <ul class="list-group list-group-unbordered">
                                        <?php $__currentLoopData = $top_article_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="list-group-item">
                                                <i class="fa fa-hand-o-right"></i>
                                                <a href="<?php echo e(route('article',$article->id)); ?>"
                                                   class="title-link"><?php echo e($article->title); ?></a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
<!--                        <div class="row">
                            <div class="box box-solid">
                                <div class="box-header with-border">
                                    <i class="fa fa-tags"></i>

                                    <h3 class="box-title">Label云</h3>
                                </div>
                                <div class="box-body">
                                    <?php $__currentLoopData = $tag_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(route('tag',$t_list->id)); ?>"
                                           <?php switch(($t_list->id)%5): case (0): ?>class="tag btn btn-flat btn-xs bg-black"
                                           <?php break; ?> <?php case (1): ?>class="tag btn btn-flat btn-xs bg-olive"
                                           <?php break; ?> <?php case (2): ?>class="tag
                                            btn btn-flat btn-xs bg-blue"
                                           <?php break; ?> <?php case (3): ?>class="tag btn btn-flat btn-xs bg-purple"
                                           <?php break; ?> <?php default: ?> class="tag btn btn-flat btn-xs
                                            bg-maroon" <?php endswitch; ?>><?php echo e($t_list->name); ?>

                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="box box-solid">
                                <div class="box-header with-border">
                                    <i class="fa fa-link"></i>

                                    <h3 class="box-title">友情链接</h3>
                                </div>
                                <div class="box-body">
                                    <?php $__currentLoopData = $link_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e($l_list->url); ?>" class="tag btn btn-flat btn-sm bg-gray"
                                           target="_blank"><?php echo e($l_list->name); ?></a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="box box-solid">
                                <div class="box-header with-border">
                                    <i class="fa fa-search"></i>

                                    <h3 class="box-title">全站Search </h3>
                                </div>
                                <div class="box-body">
                                    <form action="<?php echo e(route('search')); ?>" method="get">
                                        <div class="form-group">
                                            <input type="text" class="form-control" name="keyword" placeholder="Search ">
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>-->
                    </div>
                </div>
            </section>
        </div>
    </div>
    <footer class="main-footer">
        <div class="container">
<!--            <div class="pull-right hidden-xs">
                <a target="_blank" href="<?php echo e($config['site_110beian_link']); ?>"
                   style="display:inline-block;text-decoration:none;height:20px;line-height:20px;"><img
                        src="<?php echo e(asset('img/beian.png')); ?>" style="float:left;"/>
                    <p style="float:left;height:20px;line-height:20px;margin: 0px 0px 0px 5px; color:#939393;"><?php echo e($config['site_110beian_num']); ?></p>
                </a>
                <a target="_blank" href="http://www.miit.gov.cn/"
                   style="display:inline-block;text-decoration:none;height:20px;line-height:20px;"><p
                        style="float:left;height:20px;line-height:20px;margin: 0px 0px 0px 5px; color:#939393;">
                        | <?php echo e($config['site_icp_num']); ?></p></a>
            </div>
            <strong>Copyright11 &copy; <?php echo e(date('Y')); ?>

                <a class="title-link" href="https://imwnk.cn/admin">BLOGS</a>.</strong> All rights reserved.-->
        </div>
    </footer>
</div>
<script src="https://cdn.jsdelivr.net/npm/jquery@3/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@3/dist/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@2/dist/js/adminlte.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/node-pace-progress@1/pace.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@7/dist/sweetalert2.all.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/return-top@1/dist/x-return-top.min.js" left="90%" bottom="5%"
        text="Back顶部"></script>
<?php echo $__env->make('vendor.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('js'); ?>
<script>
    // 兼容小屏幕
    $(function () {
        if (screen.width < 768) {
            $("div#main").removeClass("container");
        }
        var _hmt = _hmt || [];
        (function () {
            var hm = document.createElement("script");
            hm.src = "https://hm.baidu.com/hm.js?<?php echo e(config('global.bd_tongji_id')); ?>";
            var s = document.getElementsByTagName("script")[0];
            s.parentNode.insertBefore(hm, s);
        })();
        (function () {
            var bp = document.createElement('script');
            var curProtocol = window.location.protocol.split(':')[0];
            if (curProtocol === 'https') {
                bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
            }
            else {
                bp.src = 'http://push.zhanzhang.baidu.com/push.js';
            }
            let s = document.getElementsByTagName("script")[0];
            s.parentNode.insertBefore(bp, s);
        })();
        <!-- Google Analytics -->
        (function (i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r;
            i[r] = i[r] || function () {
                (i[r].q = i[r].q || []).push(arguments)
            }, i[r].l = 1 * new Date();
            a = s.createElement(o),
                m = s.getElementsByTagName(o)[0];
            a.async = 1;
            a.src = g;
            m.parentNode.insertBefore(a, m)
        })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');

        ga('create', '<?php echo e(config("global.google_analytics_id")); ?>', 'auto');
        ga('send', 'pageview');
        <!-- End Google Analytics -->
    });
</script>
</body>

</html>
<?php /**PATH D:\CODES2\xtl-blogs\resources\views\layouts\frontend.blade.php ENDPATH**/ ?>
