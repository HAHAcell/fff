$.validator.setDefaults({
    ignore: ":hidden", highlight: function (e) {
        $(e).closest(".form-group").removeClass("has-success").addClass("has-error")
    }, success: function (e) {
        e.closest(".form-group").removeClass("has-error").addClass("has-success")
    }, errorElement: "span", errorPlacement: function (e, r) {
        e.appendTo(r.is(":radio") || r.is(":checkbox") ? r.parent().parent().parent() : r.parent())
    }, errorClass: "help-block", validClass: "help-block"
});
$.validator.addMethod("regex", function (value, element, params) {
    exp = new RegExp(params);
    return exp.test(value)
}, "格式错误");
$(function () {
    e = "<i class='fa fa-times-circle'></i> &nbsp;";
    $("#createTagForm,#editTagForm").validate({
        rules: {name: {required: !0,}, flag: {required: !0,}},
        messages: {name: {required: e + "Please Enter Label Name",}, flag: {required: e + "Please Enter Label标识",}}
    });
    $("#createCategoryForm,#editCategoryForm").validate({
        rules: {
            name: {required: !0,},
            flag: {required: !0,},
            keywords: {required: !0,},
            description: {required: !0,},
            parent_id: {required: !0,},
            sort: {required: !0,}
        },
        messages: {
            name: {required: e + "Please Enter Column名",},
            flag: {required: e + "Please Enter Column标识",},
            keywords: {required: e + "Please Enter Keyword",},
            description: {required: e + "Please Enter Describe",},
            parent_id: {required: e + "Please choose 父级Column",},
            sort: {required: e + "Please Enter 排序权重",}
        }
    });
    $("#createNavForm,#editNavForm").validate({
        rules: {
            name: {required: !0,},
            type: {required: !0,},
            parent_id: {required: !0,},
            sort: {required: !0, number: true},
            status: {required: !0,}
        },
        messages: {
            name: {required: e + "Please Enter 菜单名",},
            type: {required: e + "Please Enter 菜单类型",},
            parent_id: {required: e + "Please choose 父级菜单",},
            sort: {required: e + "Please Enter 排序权重", number: e + "Please Enter 合法的数字"},
            status: {required: e + "Please choose Status",},
        }
    });
    $("#createArticleForm,#editArticleForm").validate({
        rules: {
            title: {required: !0,},
            tag_ids: {required: !0,},
            category_id: {required: !0,},
            author: {required: !0,},
            content: {required: !0,},
            keywords: {required: !0,},
            status: {required: !0,}
        },
        messages: {
            title: {required: e + "Please Enter Label Name",},
            category_id: {required: e + "Please choose Column",},
            tag_ids: {required: e + "请至少选择一个Label",},
            author: {required: e + "Please Enter Author",},
            content: {required: e + "Please Enter Content",},
            keywords: {required: e + "Please Enter Keyword",},
            status: {required: e + "yes否Publish",}
        }
    });
    $("#createPageForm,#editPageForm").validate({
        rules: {
            title: {required: !0,},
            author: {required: !0,},
            content: {required: !0,},
            status: {required: !0,}
        },
        messages: {
            title: {required: e + "Please Enter Label Name",},
            author: {required: e + "Please Enter Author",},
            content: {required: e + "Please Enter Content",},
            status: {required: e + "yes否Publish",}
        }
    });
    $("#createPushForm").validate({
        rules: {
            subject: {required: !0,},
            target: {required: !0,},
            method: {required: !0,},
            content: {required: !0,}
        },
        messages: {
            subject: {required: e + "Please Enter 主题",},
            target: {required: e + "Please choose 推送用户",},
            method: {required: e + "Please choose 推送方式",},
            content: {required: e + "推送Content Cannot be empty",}
        }
    });
    $("#createLinkForm,#editLinkForm").validate({
        rules: {name: {required: !0,}, url: {required: !0, url: true}},
        messages: {name: {required: e + "Please Enter 友链名",}, url: {required: e + "Please Enter 友链地址", url: e + "Please Enter 正确的链接"}}
    });
    $("#editProfileForm").validate({
        rules: {name: {required: !0,}, email: {required: !0, email: true}},
        messages: {name: {required: e + "Please Enter User Name",}, email: {required: e + "Please Enter Email", email: e + "Please Enter 正确的Email地址"}}
    });
    $("#changePassForm").validate({
        rules: {
            old_password: {required: !0,},
            password: {required: !0,},
            password_confirmation: {required: !0, equalTo: "#password"}
        },
        messages: {
            old_password: {required: e + "Please Enter Old Password",},
            password: {required: e + "Please Enter New Password",},
            password_confirmation: {required: e + "Please ConfirmNew Password", equalTo: e + "两次password不一致"}
        }
    });
    $("#createPermissionForm,#editPermissionForm").validate({
        rules: {name: {required: !0,}, route: {required: !0,}},
        messages: {name: {required: e + "Please Enter 权限名称",}, route: {required: e + "Please Enter 权限路由",}}
    });
    $("#createRoleForm,#editRoleForm").validate({
        rules: {name: {required: !0,}},
        messages: {name: {required: e + "Please Enter 角色名称",}}
    });
    $("#createUserForm,#editUserForm").validate({
        rules: {
            roles: {required: !0,},
            name: {required: !0,},
            email: {required: !0, email: true},
            password: {required: !0,},
            password_confirmation: {required: !0, equalTo: "#password"},
            status: {required: !0,}
        },
        messages: {
            roles: {required: e + "请至少选择一个角色",},
            name: {required: e + "Please Enter User Name",},
            email: {required: e + "Please Enter Email", email: e + "Please Enter 正确的Email地址"},
            password: {required: e + "Please Enter password",},
            password_confirmation: {required: e + "请Confirm password", equalTo: e + "两次password不一致"},
            status: {required: e + "Please choose Status",},
        }
    })
});
