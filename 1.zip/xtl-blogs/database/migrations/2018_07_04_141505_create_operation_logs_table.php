<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateOperationLogsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('operation_logs', function (Blueprint $table) {
            $table->increments('id')->comment('Operate记录ID');
            $table->string('operator')->comment('操Author');;
            $table->string('operation')->comment('Operate');;
            $table->string('ip')->comment('ip');;
            $table->integer('operation_time')->comment('Time');;
            $table->string('address')->comment('地址');;
            $table->string('device')->comment('设备');;
            $table->string('browser')->comment('browse器');;
            $table->string('platform')->comment('平台');;
            $table->string('language')->comment('语言');;
            $table->string('device_type')->comment('设备类型');;
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('operation_logs');
    }
}
