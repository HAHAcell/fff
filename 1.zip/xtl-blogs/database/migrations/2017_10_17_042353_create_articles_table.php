<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateArticlesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('articles', function (Blueprint $table) {
            $table->increments('id')->comment('文章ID');
            $table->unsignedInteger('category_id')->default(0)->comment('分类id');
            $table->string('title')->comment('Title');
            $table->string('author')->comment('Author');
            $table->char('description')->comment('Describe');
            $table->string('keywords')->comment('Keyword');
            $table->boolean('status')->default(0)->comment('yes否Publish 1yes 0否');
            $table->boolean('is_top')->default(0)->comment('yes否Top 1yes 0否');
            $table->unsignedInteger('click')->default(0)->comment('点击数');
            $table->string('rank')->nullable()->comment('热度');
            $table->boolean('allow_comment')->default(1)->comment('Hot');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('articles');
    }
}
