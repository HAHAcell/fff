<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->increments('id')->comment('用户ID');
            $table->string('name')->comment('User Name');
            $table->string('avatar')->default('')->comment('用户头像');
            $table->string('email')->unique()->comment('Email');
            $table->string('password')->comment('password');
            $table->rememberToken()->comment('yes否记住Login');
            $table->boolean('status')->default(1)->comment('Status 1正常 0限制');
            $table->timestamp('last_login_at')->nullable()->comment('最后LoginTime');
            $table->string('last_login_ip')->nullable()->comment('最后LoginIP');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
