<?php

namespace App\Http\Requests\Article;

use Illuminate\Foundation\Http\FormRequest;

class Store extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'category_id'   => 'required|string',
            'title'         => 'required|string',
            'author'        => 'required|string',
            'keywords'      => 'required|string',
            'tag_ids'       => 'required',
            'content'       => 'required|string',
            'status'        => 'required',
            'is_top'        => 'required',
            'allow_comment' => 'required',
        ];
    }

    /**
     * 定义字段名中文
     *
     * @return array
     */
    public function attributes()
    {
        return [
            'category_id'   => '分类',
            'title'         => 'Title',
            'author'        => 'Author',
            'tag_ids'       => 'Label',
            'keywords'      => 'Keyword',
            'content'       => 'Content',
            'status'        => 'Status',
            'is_top'        => 'Top',
            'allow_comment' => 'Hot',
        ];
    }

    /**
     * 定义字段名中文
     *
     * @return array
     */
    public function messages()
    {
        return [
            'tag_ids.required' => '必须选择Label',
        ];
    }
}
