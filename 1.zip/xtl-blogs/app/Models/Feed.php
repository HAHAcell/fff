<?php

namespace App\Models;

class Feed extends Base
{
    const TYPE_ARTICLE = 0;
    const TYPE_PAGE = 1;
}
