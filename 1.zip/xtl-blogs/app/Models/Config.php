<?php

namespace App\Models;


class Config extends Base
{
    //
}
