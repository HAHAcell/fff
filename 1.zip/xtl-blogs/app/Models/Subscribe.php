<?php

namespace App\Models;

class Subscribe extends Base
{
    const PUSH_NOW = 0;
    const PUSH_DELAY = 1;

}
