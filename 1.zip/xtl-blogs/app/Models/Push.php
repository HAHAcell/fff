<?php

namespace App\Models;

use Carbon\Carbon;

class Push extends Base
{
    /**
     * 获取StatusLabel
     *
     * @return string
     */
    public function getStatusTagAttribute()
    {
        return $this->attributes['started_at'] < Carbon::now()
            ? '<a href="javascript:void(0)" class="btn btn-sm btn-success btn-flat">已完成</a>'
            : '<a href="javascript:void(0)" class="btn btn-sm btn-danger btn-flat">未完成</a>';
    }

    /**
     * 获取方式Label
     *
     * @return string
     */
    public function getMethodTagAttribute()
    {
        return $this->attributes['method'] === 0 ? '立即推送' : '定时推送';
    }
}
