<?php

namespace App\Models;

class OperationLog extends Base
{
    //
}
