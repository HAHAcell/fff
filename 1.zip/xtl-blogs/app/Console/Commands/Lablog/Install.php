<?php

namespace App\Console\Commands\BLOGS;

use Illuminate\Console\Command;

class Install extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'BLOGS:install';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'BLOGS Init';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * 安装开始
     */
    public function handle()
    {
        $this->warn('========== 初始化配置 ==========');
        $this->call('BLOGS:init');
        $this->warn('========== 请手动执行 ==========');
        $this->info('php artisan BLOGS:migrate');


    }
}
