<?php

namespace App\Console\Commands\BLOGS;

use Illuminate\Console\Command;
use Illuminate\Auth\Events\Registered;
use Illuminate\Support\Facades\Hash;
use App\Models\User;

class RegisterUser extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'BLOGS:register';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Register Admin';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * 注册用户
     */
    public function handle()
    {

        $username = $this->ask('Please Enter User Name', false);
        $email = $this->ask('Please Enter Email', false);
        $password = $this->ask('Please Enter password', false);
        event(new Registered($createOrFail = User::create([
            'name'     => $username,
            'email'    => $email,
            'password' => Hash::make($password),
            'status'   => 1,
            'avatar'   => '\uploads\avatar\default.png',
        ])));
        $this->warn('=======！！！ 牢记注册信息 ！！！=======');
        $this->line('管理员Email：'.$email);
        $this->line('管理员password：'.$password);
        $this->warn('=======！！！ 牢记注册信息 ！！！=======');
    }
}
