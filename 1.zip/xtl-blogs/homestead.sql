/*
 Navicat Premium Data Transfer

 Source Server         : 127.0.0.1
 Source Server Type    : MySQL
 Source Server Version : 80031
 Source Host           : 127.0.0.1:3306
 Source Schema         : homestead

 Target Server Type    : MySQL
 Target Server Version : 80031
 File Encoding         : 65001

 Date: 26/11/2023 23:21:46
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for article_tags
-- ----------------------------
DROP TABLE IF EXISTS `article_tags`;
CREATE TABLE `article_tags`  (
  `article_id` int(0) UNSIGNED NOT NULL DEFAULT 0 COMMENT '文章ID',
  `tag_id` int(0) UNSIGNED NOT NULL DEFAULT 0 COMMENT '标签ID'
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Fixed;

-- ----------------------------
-- Records of article_tags
-- ----------------------------
INSERT INTO `article_tags` VALUES (1, 1);
INSERT INTO `article_tags` VALUES (2, 1);
INSERT INTO `article_tags` VALUES (3, 1);
INSERT INTO `article_tags` VALUES (4, 1);
INSERT INTO `article_tags` VALUES (5, 1);
INSERT INTO `article_tags` VALUES (6, 1);
INSERT INTO `article_tags` VALUES (7, 1);
INSERT INTO `article_tags` VALUES (8, 1);

-- ----------------------------
-- Table structure for articles
-- ----------------------------
DROP TABLE IF EXISTS `articles`;
CREATE TABLE `articles`  (
  `id` int(0) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '文章ID',
  `category_id` int(0) UNSIGNED NOT NULL DEFAULT 0 COMMENT '分类id',
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '标题',
  `author` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '作者',
  `description` char(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '描述',
  `keywords` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '关键词',
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否发布 1是 0否',
  `is_top` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否置顶 1是 0否',
  `click` int(0) UNSIGNED NOT NULL DEFAULT 0 COMMENT '点击数',
  `rank` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '热度',
  `allow_comment` tinyint(1) NOT NULL DEFAULT 1 COMMENT '是否允许评论',
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of articles
-- ----------------------------
INSERT INTO `articles` VALUES (1, 1, '少女', 'admin', '风和刘海肆意地交谈', '歌词', 1, 1, 22, '1.7128254112507413', 1, '2023-11-17 14:20:35', '2023-11-26 22:39:56', NULL);
INSERT INTO `articles` VALUES (2, 1, '小雨中', 'admin', '小雨中', '小雨中', 1, 1, 10, '1.7128254112507413', 1, '2023-11-17 14:22:22', '2023-11-26 20:08:13', NULL);
INSERT INTO `articles` VALUES (3, 1, '赵雷新专辑署前街少年发布，你们听了么', 'admin', '赵雷新专辑署前街少年发布，你们听了么', '赵雷', 1, 1, 24, '1.7128254112507413', 1, '2023-11-17 14:26:09', '2023-11-26 21:56:33', NULL);
INSERT INTO `articles` VALUES (4, 1, '111111111', 'admin', 'hghgjhgjhgjhghj', 'eeee', 1, 0, 1, '1.7128254112507413', 0, '2023-11-25 16:14:29', '2023-11-26 20:05:22', '2023-11-26 20:05:22');
INSERT INTO `articles` VALUES (5, 1, '11111111111', 'admin', '22222222222', '11', 0, 0, 0, '1.7128254112507413', 0, '2023-11-26 19:44:56', '2023-11-26 20:05:17', '2023-11-26 20:05:17');
INSERT INTO `articles` VALUES (6, 1, 'hahha', 'admin', 'sdfdsa', '1111', 1, 1, 20, '1.7128254112507413', 0, '2023-11-26 21:21:01', '2023-11-26 22:40:47', NULL);
INSERT INTO `articles` VALUES (7, 1, 'english test', 'admin', 'ddddddddddddddddddd', 'english test', 1, 0, 1, '1.7128254112507413', 0, '2023-11-26 21:58:00', '2023-11-26 22:17:06', NULL);
INSERT INTO `articles` VALUES (8, 1, '3333333333', 'admin', 'ddddddddddddddddddd', '22', 1, 0, 1, '1.7128254112507413', 0, '2023-11-26 22:16:53', '2023-11-26 22:16:58', NULL);

-- ----------------------------
-- Table structure for categories
-- ----------------------------
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories`  (
  `id` int(0) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `parent_id` int(0) UNSIGNED NOT NULL DEFAULT 0 COMMENT '父级ID',
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '栏目名',
  `flag` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '标签标识',
  `keywords` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '关键词',
  `description` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '描述',
  `sort` tinyint(0) UNSIGNED NOT NULL DEFAULT 1 COMMENT '排序',
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 8 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of categories
-- ----------------------------
INSERT INTO `categories` VALUES (1, 0, 'Default', 'default', 'default', 'default', 100, '2018-01-01 00:00:00', '2023-11-17 14:16:08');

-- ----------------------------
-- Table structure for comments
-- ----------------------------
DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments`  (
  `id` int(0) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '评论ID',
  `article_id` int(0) UNSIGNED NOT NULL DEFAULT 0 COMMENT '文章id',
  `nickname` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '昵称',
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '邮箱',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '留言',
  `reply` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '回复',
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '状态',
  `ip` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '评论ip',
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of comments
-- ----------------------------
INSERT INTO `comments` VALUES (1, 3, 'edge', 'edge@163.com', '你好啊', '好的 好的', 1, '::1', '2023-11-17 14:41:10', '2023-11-17 14:44:19');
INSERT INTO `comments` VALUES (2, 2, '哈哈', '312985913@qq.com', '歌词写的很好', NULL, 1, '::1', '2023-11-17 14:45:54', '2023-11-17 14:47:46');
INSERT INTO `comments` VALUES (3, 3, 'wwww', '312985913@qq.com', '年度听的最多的歌曲', NULL, 1, '::1', '2023-11-25 16:10:14', '2023-11-25 16:10:59');

-- ----------------------------
-- Table structure for configs
-- ----------------------------
DROP TABLE IF EXISTS `configs`;
CREATE TABLE `configs`  (
  `id` int(0) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '配置项键名',
  `value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '配置项键值',
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 25 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of configs
-- ----------------------------
INSERT INTO `configs` VALUES (1, 'site_status', '1', '2018-01-01 00:00:00', '2018-01-01 00:00:00');
INSERT INTO `configs` VALUES (2, 'site_close_word', '署前街站点维护，临时关闭', '2018-01-01 00:00:00', '2018-01-01 00:00:00');
INSERT INTO `configs` VALUES (3, 'site_name', 'BLOGS', '2018-01-01 00:00:00', '2018-01-01 00:00:00');
INSERT INTO `configs` VALUES (4, 'site_title', '署前街TITLE', '2018-01-01 00:00:00', '2018-01-01 00:00:00');
INSERT INTO `configs` VALUES (5, 'site_keywords', '赵雷,xx,xxx,个人博客,lablog,技术分享,署前街的少年', '2018-01-01 00:00:00', '2018-01-01 00:00:00');
INSERT INTO `configs` VALUES (6, 'site_description', '署前街的个人技术博客', '2018-01-01 00:00:00', '2018-01-01 00:00:00');
INSERT INTO `configs` VALUES (7, 'site_icp_num', '苏ICP备xxx号11111', '2018-01-01 00:00:00', '2018-01-01 00:00:00');
INSERT INTO `configs` VALUES (8, 'site_admin', 'BLOGS', '2018-01-01 00:00:00', '2018-01-01 00:00:00');
INSERT INTO `configs` VALUES (9, 'site_admin_mail', '//mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email=xxx', '2018-01-01 00:00:00', '2018-01-01 00:00:00');
INSERT INTO `configs` VALUES (10, 'site_admin_weibo', '//weibo.com/xxx', '2018-01-01 00:00:00', '2018-01-01 00:00:00');
INSERT INTO `configs` VALUES (11, 'site_admin_github', '//gitee.com/xxx', '2018-01-01 00:00:00', '2018-01-01 00:00:00');
INSERT INTO `configs` VALUES (12, 'site_admin_info', 'BLOGS', '2018-01-01 00:00:00', '2018-01-01 00:00:00');
INSERT INTO `configs` VALUES (13, 'site_info', '署前街-本站发布的系统与软件仅为个人学习测试使用，请在下载后24小时内删除，不得用于任何商业用途，否则后果自负，请支持购买正版软件！如侵犯到您的权益,请及时通知我们,我们会及时处理。', '2018-01-01 00:00:00', '2018-01-01 00:00:00');
INSERT INTO `configs` VALUES (14, 'site_admin_avatar', '/uploads/avatar/default.png', '2018-01-01 00:00:00', '2018-01-01 00:00:00');
INSERT INTO `configs` VALUES (15, 'site_mailto_admin', '312985913@qq.com', '2018-01-01 00:00:00', '2018-01-01 00:00:00');
INSERT INTO `configs` VALUES (16, 'site_110beian_num', '苏公网安备 22222222号', '2018-01-01 00:00:00', '2018-01-01 00:00:00');
INSERT INTO `configs` VALUES (17, 'site_110beian_link', 'http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=xxx', '2018-01-01 00:00:00', '2018-01-01 00:00:00');
INSERT INTO `configs` VALUES (18, 'site_allow_comment', '1', '2018-01-01 00:00:00', '2018-01-01 00:00:00');
INSERT INTO `configs` VALUES (19, 'site_allow_message', '1', '2018-01-01 00:00:00', '2018-01-01 00:00:00');
INSERT INTO `configs` VALUES (20, 'site_allow_subscribe', '1', '2018-01-01 00:00:00', '2018-01-01 00:00:00');
INSERT INTO `configs` VALUES (21, 'allow_reward', '1', '2018-01-01 00:00:00', '2018-01-01 00:00:00');
INSERT INTO `configs` VALUES (22, 'wepay', '1', '2018-01-01 00:00:00', '2018-01-01 00:00:00');
INSERT INTO `configs` VALUES (23, 'alipay', '', '2018-01-01 00:00:00', '2018-01-01 00:00:00');
INSERT INTO `configs` VALUES (24, 'water_mark_status', '1', '2018-01-01 00:00:00', '2018-01-01 00:00:00');

-- ----------------------------
-- Table structure for failed_jobs
-- ----------------------------
DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs`  (
  `id` bigint(0) UNSIGNED NOT NULL AUTO_INCREMENT,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of failed_jobs
-- ----------------------------

-- ----------------------------
-- Table structure for feeds
-- ----------------------------
DROP TABLE IF EXISTS `feeds`;
CREATE TABLE `feeds`  (
  `id` int(0) UNSIGNED NOT NULL AUTO_INCREMENT,
  `target_type` tinyint(0) UNSIGNED NOT NULL COMMENT '类型0文章1单页',
  `target_id` int(0) UNSIGNED NOT NULL COMMENT '关联类型ID',
  `content` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'markdown内容',
  `html` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'markdown转的html内容',
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `idx_type_id`(`target_type`, `target_id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of feeds
-- ----------------------------
INSERT INTO `feeds` VALUES (1, 0, 1, '偶尔化一化妆吧\r\n\r\n我们从来就不会老\r\n\r\n那是镜子的玩笑\r\n\r\n在玻璃窗前伸伸你的懒腰\r\n\r\n找出你褶皱的裙子趁阳光高照\r\n\r\n穿给你的影子看\r\n\r\n风和刘海肆意地交谈\r\n\r\n不需要任何语言\r\n\r\n你送走昨天 轻轻落下脚尖\r\n\r\n转身与你重复道别的人已走远\r\n\r\n哦 别回望少女\r\n\r\n那是逆流的往昔\r\n\r\n你舞动的俏影\r\n\r\n隔着玻璃\r\n\r\n提醒你时刻要保护好自己\r\n\r\n忧伤会忘记帆布鞋上的你\r\n\r\n在梅雨的黑夜里\r\n\r\n在无所谓的方向里\r\n\r\n装满晚风的外衣\r\n\r\n树影拂掠过末班车的眼睛\r\n\r\n孤单的人坐在最后一排座椅\r\n\r\n哦 仰起头 少女\r\n\r\n从来没有什么真正属于你\r\n\r\n也不曾失去\r\n\r\n因为你是少女\r\n\r\n不需要解释也不需要在意\r\n\r\n就让提问的人继续猜下去', '<p>偶尔化一化妆吧</p>\n<p>我们从来就不会老</p>\n<p>那是镜子的玩笑</p>\n<p>在玻璃窗前伸伸你的懒腰</p>\n<p>找出你褶皱的裙子趁阳光高照</p>\n<p>穿给你的影子看</p>\n<p>风和刘海肆意地交谈</p>\n<p>不需要任何语言</p>\n<p>你送走昨天 轻轻落下脚尖</p>\n<p>转身与你重复道别的人已走远</p>\n<p>哦 别回望少女</p>\n<p>那是逆流的往昔</p>\n<p>你舞动的俏影</p>\n<p>隔着玻璃</p>\n<p>提醒你时刻要保护好自己</p>\n<p>忧伤会忘记帆布鞋上的你</p>\n<p>在梅雨的黑夜里</p>\n<p>在无所谓的方向里</p>\n<p>装满晚风的外衣</p>\n<p>树影拂掠过末班车的眼睛</p>\n<p>孤单的人坐在最后一排座椅</p>\n<p>哦 仰起头 少女</p>\n<p>从来没有什么真正属于你</p>\n<p>也不曾失去</p>\n<p>因为你是少女</p>\n<p>不需要解释也不需要在意</p>\n<p>就让提问的人继续猜下去</p>', '2023-11-17 14:20:35', '2023-11-26 17:34:02');
INSERT INTO `feeds` VALUES (2, 0, 2, '作词: 赵雷\r\n\r\n作曲: 赵雷\r\n\r\n制作人: 赵雷\r\n\r\n小雨中 不知道哪把花伞下是你\r\n\r\n邮递员 来过却没有留下你的信\r\n ![未命名](/uploads/content/20231117/image_1700202180_wRpzvSXJSb.png) \r\n\r\n\r\n\r\n我知道 我不是一个很聪明的人\r\n\r\n执着中 我会衰老你会更清醒\r\n\r\n哦 我不了解你\r\n\r\n哦 我看不清你\r\n\r\n秋来时 梦里仿似有个人是你\r\n\r\n当落叶枯去\r\n\r\n你会不会为它闭上眼睛\r\n\r\n哦 我看不清你\r\n\r\n我会洗净枕旁你留下的余香\r\n\r\n小雨中 不知道哪把花伞下是你\r\n\r\n邮递员 来过却没有留下你的信\r\n\r\n我知道 我不是一个很聪明的人\r\n\r\n执着中 我会衰老你会更清醒\r\n\r\n哦 我不了解你哦我看不清你\r\n\r\n秋来时 梦里仿似有个人是你\r\n\r\n当落叶枯去 你会不会为它闭上眼睛\r\n\r\n哦 我看不清你 我会洗净枕旁你留下的余香\r\n\r\n封面设计：韩东、小强、阿穆隆\r\n\r\n母带工程师：Randy Merrill\r\n\r\n母带工程室：Sterling Sound\r\n\r\n录音室：野火春风、摩登天空\r\n\r\n混音师：姜北生\r\n\r\n录音师：李越、张俊\r\n\r\nMIDI制作：PUPU朴朴\r\n\r\n键盘：PUPU朴朴、姜伯虎\r\n\r\n打击乐：PUPU朴朴\r\n\r\n鼓：Chris Trzcinski\r\n\r\n贝斯：PUPU朴朴、旭东\r\n\r\n电吉他：董长跃\r\n\r\n木吉他：赵雷\r\n\r\n编曲：PUPU朴朴', '<p>作词: 赵雷</p>\n<p>作曲: 赵雷</p>\n<p>制作人: 赵雷</p>\n<p>小雨中 不知道哪把花伞下是你</p>\n<p>邮递员 来过却没有留下你的信\n<img src=\"/uploads/content/20231117/image_1700202180_wRpzvSXJSb.png\" alt=\"未命名\" /> </p>\n<p>我知道 我不是一个很聪明的人</p>\n<p>执着中 我会衰老你会更清醒</p>\n<p>哦 我不了解你</p>\n<p>哦 我看不清你</p>\n<p>秋来时 梦里仿似有个人是你</p>\n<p>当落叶枯去</p>\n<p>你会不会为它闭上眼睛</p>\n<p>哦 我看不清你</p>\n<p>我会洗净枕旁你留下的余香</p>\n<p>小雨中 不知道哪把花伞下是你</p>\n<p>邮递员 来过却没有留下你的信</p>\n<p>我知道 我不是一个很聪明的人</p>\n<p>执着中 我会衰老你会更清醒</p>\n<p>哦 我不了解你哦我看不清你</p>\n<p>秋来时 梦里仿似有个人是你</p>\n<p>当落叶枯去 你会不会为它闭上眼睛</p>\n<p>哦 我看不清你 我会洗净枕旁你留下的余香</p>\n<p>封面设计：韩东、小强、阿穆隆</p>\n<p>母带工程师：Randy Merrill</p>\n<p>母带工程室：Sterling Sound</p>\n<p>录音室：野火春风、摩登天空</p>\n<p>混音师：姜北生</p>\n<p>录音师：李越、张俊</p>\n<p>MIDI制作：PUPU朴朴</p>\n<p>键盘：PUPU朴朴、姜伯虎</p>\n<p>打击乐：PUPU朴朴</p>\n<p>鼓：Chris Trzcinski</p>\n<p>贝斯：PUPU朴朴、旭东</p>\n<p>电吉他：董长跃</p>\n<p>木吉他：赵雷</p>\n<p>编曲：PUPU朴朴</p>', '2023-11-17 14:22:22', '2023-11-26 17:33:56');
INSERT INTO `feeds` VALUES (3, 0, 3, '77等于49\r\n77等于492023-01-14 02:27:41发布于山西\r\n点灭只看此人举报21楼\r\n我真的每一首都好好听\r\n\r\n阿卿阿松\r\n阿卿阿松2023-01-14 02:57:52发布于四川\r\n点灭只看此人举报22楼\r\n一开始最喜欢我记得 后来是程艾影 结果少女成了我网易云的年度听的最多的歌曲\r\n\r\n舔狗杀手007\r\n舔狗杀手0072023-01-14 15:29:46发布于山东\r\n点灭只看此人举报23楼\r\n更喜欢两年前发布的有点emo版的小行迹', '<p>77等于49\n77等于492023-01-14 02:27:41发布于山西\n点灭只看此人举报21楼\n我真的每一首都好好听</p>\n<p>阿卿阿松\n阿卿阿松2023-01-14 02:57:52发布于四川\n点灭只看此人举报22楼\n一开始最喜欢我记得 后来是程艾影 结果少女成了我网易云的年度听的最多的歌曲</p>\n<p>舔狗杀手007\n舔狗杀手0072023-01-14 15:29:46发布于山东\n点灭只看此人举报23楼\n更喜欢两年前发布的有点emo版的小行迹</p>', '2023-11-17 14:26:10', '2023-11-26 20:05:41');
INSERT INTO `feeds` VALUES (4, 1, 1, '查看日志报错：\r\n\r\ncom.mysql.cj.exceptions.CJException: null,  message from server: \"Host \'xxxx\' is blocked because of many connection errors; unblock with \'mysqladmin flush-hosts\'\"\r\n\r\n首先数据库使用Navicat访问正常，但是应用访问就是不行，即使重启mysql实例也没效果。最后定位到，应该是短时间内产生了大量中断的数据库连接导致，而且失败的连接数量超过了mysql的max_connection_errors的最大值。\r\n\r\n1.登录mysql，使用 flush hosts来命令清理hosts文件\r\n\r\nflush hosts;\r\n\r\n2.调整mysql的最大连接数和最大错误连接数的大小\r\n\r\n查看mysql最大错误连接数\r\n\r\nshow variables like \'%max_connect_errors%\'\r\n\r\n查看mysql最大连接数：\r\n\r\nshow variables like \'max_connections\';\r\n\r\n修改连接数大小：\r\n\r\nset global max_connections = 1000;\r\nset global max_connect_errors = 1000;', '<p>查看日志报错：</p>\n<p>com.mysql.cj.exceptions.CJException: null,  message from server: &quot;Host \'xxxx\' is blocked because of many connection errors; unblock with \'mysqladmin flush-hosts\'&quot;</p>\n<p>首先数据库使用Navicat访问正常，但是应用访问就是不行，即使重启mysql实例也没效果。最后定位到，应该是短时间内产生了大量中断的数据库连接导致，而且失败的连接数量超过了mysql的max_connection_errors的最大值。</p>\n<p>1.登录mysql，使用 flush hosts来命令清理hosts文件</p>\n<p>flush hosts;</p>\n<p>2.调整mysql的最大连接数和最大错误连接数的大小</p>\n<p>查看mysql最大错误连接数</p>\n<p>show variables like \'%max_connect_errors%\'</p>\n<p>查看mysql最大连接数：</p>\n<p>show variables like \'max_connections\';</p>\n<p>修改连接数大小：</p>\n<p>set global max_connections = 1000;\nset global max_connect_errors = 1000;</p>', '2023-11-17 14:30:01', '2023-11-17 14:30:01');
INSERT INTO `feeds` VALUES (5, 0, 4, 'hghgjhgjhgjhghj', '<p>hghgjhgjhgjhghj</p>', '2023-11-25 16:14:29', '2023-11-26 17:34:10');
INSERT INTO `feeds` VALUES (6, 0, 5, '22222222222', '<p>22222222222</p>', '2023-11-26 19:44:56', '2023-11-26 19:44:56');
INSERT INTO `feeds` VALUES (7, 0, 6, 'sdfdsa', '<p>sdfdsa</p>', '2023-11-26 21:21:01', '2023-11-26 22:04:21');
INSERT INTO `feeds` VALUES (8, 0, 7, 'ddddddddddddddddddd', '<p>ddddddddddddddddddd</p>', '2023-11-26 21:58:00', '2023-11-26 21:58:00');
INSERT INTO `feeds` VALUES (9, 0, 8, 'ddddddddddddddddddd', '<p>ddddddddddddddddddd</p>', '2023-11-26 22:16:54', '2023-11-26 22:16:54');

-- ----------------------------
-- Table structure for jobs
-- ----------------------------
DROP TABLE IF EXISTS `jobs`;
CREATE TABLE `jobs`  (
  `id` bigint(0) UNSIGNED NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(0) UNSIGNED NOT NULL,
  `reserved_at` int(0) UNSIGNED NULL DEFAULT NULL,
  `available_at` int(0) UNSIGNED NOT NULL,
  `created_at` int(0) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `jobs_queue_index`(`queue`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of jobs
-- ----------------------------

-- ----------------------------
-- Table structure for links
-- ----------------------------
DROP TABLE IF EXISTS `links`;
CREATE TABLE `links`  (
  `id` int(0) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '友链ID',
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '链接名',
  `url` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '链接地址',
  `sort` tinyint(0) UNSIGNED NOT NULL DEFAULT 1 COMMENT '排序',
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of links
-- ----------------------------
INSERT INTO `links` VALUES (1, '博客园', 'https://www.cnblogs.com', 1, '2023-11-17 14:30:43', '2023-11-17 14:30:43');

-- ----------------------------
-- Table structure for messages
-- ----------------------------
DROP TABLE IF EXISTS `messages`;
CREATE TABLE `messages`  (
  `id` int(0) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '留言ID',
  `nickname` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '昵称',
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '邮箱',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '留言',
  `reply` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL COMMENT '站长回复',
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '状态',
  `ip` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '留言ip',
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of messages
-- ----------------------------

-- ----------------------------
-- Table structure for migrations
-- ----------------------------
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations`  (
  `id` int(0) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(0) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 21 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of migrations
-- ----------------------------
INSERT INTO `migrations` VALUES (1, '2014_10_12_000000_create_users_table', 1);
INSERT INTO `migrations` VALUES (2, '2014_10_12_100000_create_password_resets_table', 1);
INSERT INTO `migrations` VALUES (3, '2017_10_17_042353_create_articles_table', 1);
INSERT INTO `migrations` VALUES (4, '2017_10_17_140623_create_tags_table', 1);
INSERT INTO `migrations` VALUES (5, '2017_10_20_030636_create_categories_table', 1);
INSERT INTO `migrations` VALUES (6, '2017_10_21_122042_create_configs_table', 1);
INSERT INTO `migrations` VALUES (7, '2017_10_21_123201_create_links_table', 1);
INSERT INTO `migrations` VALUES (8, '2017_10_22_122848_create_article_tags_table', 1);
INSERT INTO `migrations` VALUES (9, '2018_03_03_145513_create_messages_table', 1);
INSERT INTO `migrations` VALUES (10, '2018_07_04_141505_create_operation_logs_table', 1);
INSERT INTO `migrations` VALUES (11, '2018_07_17_133620_create_comments_table', 1);
INSERT INTO `migrations` VALUES (12, '2018_07_20_142549_create_oauth_infos_table', 1);
INSERT INTO `migrations` VALUES (13, '2018_07_27_090421_create_permission_tables', 1);
INSERT INTO `migrations` VALUES (14, '2018_08_09_145825_create_navs_table', 1);
INSERT INTO `migrations` VALUES (15, '2018_08_09_160942_create_pages_table', 1);
INSERT INTO `migrations` VALUES (16, '2018_08_11_221757_create_jobs_table', 1);
INSERT INTO `migrations` VALUES (17, '2018_08_11_222305_create_failed_jobs_table', 1);
INSERT INTO `migrations` VALUES (18, '2018_08_12_100220_create_subscribes_table', 1);
INSERT INTO `migrations` VALUES (19, '2018_08_15_091803_create_feeds_table', 1);
INSERT INTO `migrations` VALUES (20, '2018_09_12_155642_create_pushes_table', 1);

-- ----------------------------
-- Table structure for model_has_permissions
-- ----------------------------
DROP TABLE IF EXISTS `model_has_permissions`;
CREATE TABLE `model_has_permissions`  (
  `permission_id` int(0) UNSIGNED NOT NULL,
  `model_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(0) UNSIGNED NOT NULL,
  PRIMARY KEY (`permission_id`, `model_id`, `model_type`) USING BTREE,
  INDEX `model_has_permissions_model_type_model_id_index`(`model_type`, `model_id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of model_has_permissions
-- ----------------------------

-- ----------------------------
-- Table structure for model_has_roles
-- ----------------------------
DROP TABLE IF EXISTS `model_has_roles`;
CREATE TABLE `model_has_roles`  (
  `role_id` int(0) UNSIGNED NOT NULL,
  `model_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(0) UNSIGNED NOT NULL,
  PRIMARY KEY (`role_id`, `model_id`, `model_type`) USING BTREE,
  INDEX `model_has_roles_model_type_model_id_index`(`model_type`, `model_id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of model_has_roles
-- ----------------------------
INSERT INTO `model_has_roles` VALUES (1, 'App\\Models\\User', 1);
INSERT INTO `model_has_roles` VALUES (2, 'App\\Models\\User', 2);

-- ----------------------------
-- Table structure for navs
-- ----------------------------
DROP TABLE IF EXISTS `navs`;
CREATE TABLE `navs`  (
  `id` int(0) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '菜单ID',
  `type` tinyint(0) UNSIGNED NOT NULL DEFAULT 1 COMMENT '菜单类型',
  `parent_id` int(0) UNSIGNED NOT NULL DEFAULT 0 COMMENT '父级ID',
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '菜单名',
  `url` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '链接',
  `sort` tinyint(0) UNSIGNED NOT NULL DEFAULT 1 COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '状态',
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 8 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of navs
-- ----------------------------
INSERT INTO `navs` VALUES (1, 4, 0, '首页', 'http://localhost/', 1, 1, '2018-08-11 09:18:28', '2023-11-17 14:12:51');
INSERT INTO `navs` VALUES (2, 1, 0, '我的栏目', NULL, 2, 1, '2018-08-10 21:06:06', '2018-08-11 09:18:39');
INSERT INTO `navs` VALUES (3, 2, 0, '归档', NULL, 3, 1, '2018-08-10 22:57:46', '2018-08-10 23:30:35');
INSERT INTO `navs` VALUES (4, 0, 0, '关于', NULL, 4, 1, '2018-08-10 21:05:52', '2018-08-10 22:53:31');
INSERT INTO `navs` VALUES (5, 3, 4, '关于站点', 'http://lablog.cc/page/1', 1, 1, '2018-08-10 21:15:25', '2018-08-10 21:15:25');
INSERT INTO `navs` VALUES (6, 4, 0, '留言', 'http://lablog.cc/message', 5, 1, '2018-08-10 23:42:11', '2018-08-11 10:23:24');
INSERT INTO `navs` VALUES (7, 4, 0, '百度', 'https://www.baidu.com', 3, 1, '2023-11-17 14:11:42', '2023-11-17 14:11:42');

-- ----------------------------
-- Table structure for oauth_infos
-- ----------------------------
DROP TABLE IF EXISTS `oauth_infos`;
CREATE TABLE `oauth_infos`  (
  `id` int(0) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '三方登录信息ID',
  `user_id` int(0) UNSIGNED NOT NULL COMMENT '绑定的用户id',
  `type` tinyint(0) UNSIGNED NOT NULL DEFAULT 1 COMMENT '类型 1：QQ  2：新浪微博 3：github',
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '第三方昵称',
  `avatar` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '头像',
  `openid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '第三方用户id',
  `access_token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'access_token token',
  `last_login_ip` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '最后登录ip',
  `login_times` int(0) UNSIGNED NOT NULL DEFAULT 0 COMMENT '登录次数',
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of oauth_infos
-- ----------------------------

-- ----------------------------
-- Table structure for operation_logs
-- ----------------------------
DROP TABLE IF EXISTS `operation_logs`;
CREATE TABLE `operation_logs`  (
  `id` int(0) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '操作记录ID',
  `operator` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '操作者',
  `operation` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '操作',
  `ip` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ip',
  `operation_time` int(0) NOT NULL COMMENT '时间',
  `address` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '地址',
  `device` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '设备',
  `browser` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '浏览器',
  `platform` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '平台',
  `language` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '语言',
  `device_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '设备类型',
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 47 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of operation_logs
-- ----------------------------
INSERT INTO `operation_logs` VALUES (1, 'admin', '管理员登录', '::1', 1700128208, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (2, 'admin', '管理员登录', '::1', 1700200313, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (3, 'admin', '管理员登录', '::1', 1700200789, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (4, 'admin', '修改配置文件', '::1', 1700201220, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (5, 'admin', '修改配置文件', '::1', 1700201314, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (6, 'admin', '修改配置文件', '::1', 1700201353, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (7, 'admin', '添加菜单', '::1', 1700201502, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (8, 'admin', '编辑菜单', '::1', 1700201571, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (9, 'admin', '添加标签', '::1', 1700201625, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (10, 'admin', '添加标签', '::1', 1700201641, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (11, 'admin', '添加栏目', '::1', 1700201727, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (12, 'admin', '添加栏目', '::1', 1700201747, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (13, 'admin', '编辑栏目', '::1', 1700201768, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (14, 'admin', '编辑栏目', '::1', 1700201768, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (15, 'admin', '添加栏目', '::1', 1700201808, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (16, 'admin', '添加栏目', '::1', 1700201822, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (17, 'admin', '添加栏目', '::1', 1700201836, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (18, 'admin', '添加栏目', '::1', 1700201874, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (19, 'admin', '添加文章', '::1', 1700202035, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (20, 'admin', '添加文章', '::1', 1700202142, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (21, 'admin', '编辑文章', '::1', 1700202189, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (22, 'admin', '添加文章', '::1', 1700202370, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (23, 'admin', '添加单页', '::1', 1700202601, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (24, 'admin', '添加标签', '::1', 1700202643, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (25, 'admin', '推送消息', '::1', 1700202712, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (26, 'admin', '编辑菜单', '::1', 1700202907, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (27, 'admin', '编辑菜单', '::1', 1700202918, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (28, 'admin', '修改配置文件', '::1', 1700203068, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (29, 'admin', '回复评论', '::1', 1700203372, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (30, 'admin', '审核评论', '::1', 1700203432, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (31, 'admin', '审核评论', '::1', 1700203459, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (32, 'admin', '审核评论', '::1', 1700203666, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (33, 'admin', '添加权限', '::1', 1700203772, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (34, 'admin', '添加权限', '::1', 1700203795, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (35, 'admin', '添加角色', '::1', 1700203810, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (36, 'admin', '注册用户', '::1', 1700203929, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (37, 'teng_111', '管理员登录', '::1', 1700203970, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (38, 'teng_111', '删除标签', '::1', 1700203994, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (39, 'admin', '管理员登录', '::1', 1700204075, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (40, 'admin', '修改角色', '::1', 1700204104, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (41, 'admin', '管理员登录', '::1', 1700891856, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (42, 'admin', '管理员登录', '::1', 1700899227, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (43, 'admin', '审核评论', '::1', 1700899859, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (44, 'admin', '添加文章', '::1', 1700900069, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (45, 'admin', '管理员登录', '::1', 1700925998, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (46, 'admin', '管理员登录', '::1', 1700990508, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (47, 'admin', '删除标签', '::1', 1700991038, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (48, 'admin', '删除标签', '::1', 1700991045, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (49, 'admin', '编辑文章', '::1', 1700991110, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (50, 'admin', '编辑文章', '::1', 1700991124, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (51, 'admin', '编辑文章', '::1', 1700991142, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (52, 'admin', '删除栏目', '::1', 1700991186, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (53, 'admin', '删除栏目', '::1', 1700991189, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (54, 'admin', '删除栏目', '::1', 1700991193, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (55, 'admin', '删除栏目', '::1', 1700991195, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (56, 'admin', '删除栏目', '::1', 1700991199, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (57, 'admin', '编辑文章', '::1', 1700991222, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (58, 'admin', '编辑文章', '::1', 1700991236, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (59, 'admin', '编辑文章', '::1', 1700991242, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (60, 'admin', '编辑文章', '::1', 1700991250, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (61, 'admin', '删除标签', '::1', 1700991264, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (62, 'admin', '删除标签', '::1', 1700991270, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (63, 'admin', '删除栏目', '::1', 1700991282, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (64, 'admin', '删除栏目', '::1', 1700991286, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (65, 'admin', '管理员登录', '::1', 1700997206, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (66, 'admin', '管理员登录', '::1', 1700997269, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (67, 'admin', '缓存清理', '::1', 1700998604, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (68, 'admin', '缓存清理', '::1', 1700998606, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (69, 'admin', '添加文章', '::1', 1700999096, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (70, 'admin', '管理员登录', '::1', 1700999535, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (71, 'admin', '管理员登录', '::1', 1700999684, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (72, 'admin', '缓存清理', '::1', 1700999700, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (73, 'admin', '软删除文章', '::1', 1701000317, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (74, 'admin', '软删除文章', '::1', 1701000322, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (75, 'admin', '编辑文章', '::1', 1701000334, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (76, 'admin', '编辑文章', '::1', 1701000341, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (77, 'admin', '缓存清理', '::1', 1701000427, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (78, 'admin', '管理员登录', '::1', 1701000439, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (79, 'admin', '管理员登录', '::1', 1701001252, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (80, 'admin', '添加文章', '::1', 1701004861, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (81, 'admin', 'Edit Article', '::1', 1701005718, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (82, 'admin', '管理员Login', '::1', 1701007039, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (83, 'admin', '添加文章', '::1', 1701007080, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (84, 'admin', 'Edit Article', '::1', 1701007461, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (85, 'admin', '管理员Login', '::1', 1701008083, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (86, 'admin', '添加文章', '::1', 1701008214, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (87, 'admin', '修改User Info', '::1', 1701008700, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (88, '管理员', '修改User Info', '::1', 1701008733, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (89, '管理员', '修改User Info', '::1', 1701008740, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (90, '管理员', 'Edit User Info', '::1', 1701009033, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (91, '管理员', 'Edit User Info', '::1', 1701009038, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (92, '管理员', '修改password', '::1', 1701009336, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (93, '管理员', '管理员Login', '::1', 1701009446, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (94, '管理员', '修改password', '::1', 1701009465, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);
INSERT INTO `operation_logs` VALUES (95, '管理员', 'Edit User Info', '::1', 1701009508, 'N/A', 'WebKit', 'Chrome 119.0.0.0', 'Windows 10.0', 'zh-cn,zh', 'desktop', NULL, NULL);

-- ----------------------------
-- Table structure for pages
-- ----------------------------
DROP TABLE IF EXISTS `pages`;
CREATE TABLE `pages`  (
  `id` int(0) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '单页ID',
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '标题',
  `author` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '作者',
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '状态',
  `click` int(0) UNSIGNED NOT NULL DEFAULT 0 COMMENT '点击数',
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pages
-- ----------------------------
INSERT INTO `pages` VALUES (1, '解决MySQL连接报错Host is blocked because of many connection errors； unblock with ‘mysqladmin flush-hosts', 'admin', 1, 1, '2023-11-17 14:30:01', '2023-11-25 16:03:57', NULL);

-- ----------------------------
-- Table structure for password_resets
-- ----------------------------
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets`  (
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  INDEX `password_resets_email_index`(`email`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of password_resets
-- ----------------------------
INSERT INTO `password_resets` VALUES ('312985913@qq.com', '$2y$10$AgX.zSHP6FPyQqAe01DA7ObiRZnHW2WHs/iCPFgRWkui9g6oKmiym', '2023-11-25 23:15:54');

-- ----------------------------
-- Table structure for permissions
-- ----------------------------
DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions`  (
  `id` int(0) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `route` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '路由控制权限',
  `guard_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of permissions
-- ----------------------------
INSERT INTO `permissions` VALUES (1, '新建文章', '/admin/article/create', 'web', '2023-11-17 14:49:32', '2023-11-17 14:49:32');
INSERT INTO `permissions` VALUES (2, '用户管理', '/admin/user/manage', 'web', '2023-11-17 14:49:55', '2023-11-17 14:49:55');

-- ----------------------------
-- Table structure for pushes
-- ----------------------------
DROP TABLE IF EXISTS `pushes`;
CREATE TABLE `pushes`  (
  `id` int(0) UNSIGNED NOT NULL AUTO_INCREMENT,
  `subject` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '主题',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '内容',
  `target` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '目标用户',
  `method` tinyint(1) NOT NULL DEFAULT 0 COMMENT '推送方式 0立即 1定时',
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '状态',
  `started_at` timestamp(0) NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pushes
-- ----------------------------
INSERT INTO `pushes` VALUES (1, '公告消息', '<p>小雨中 不知道哪把花伞下是你</p>\n<p>邮递员 来过却没有留下你的信</p>', '1', 0, 1, '2023-11-17 14:31:52', '2023-11-17 14:31:52', '2023-11-17 14:31:52');

-- ----------------------------
-- Table structure for role_has_permissions
-- ----------------------------
DROP TABLE IF EXISTS `role_has_permissions`;
CREATE TABLE `role_has_permissions`  (
  `permission_id` int(0) UNSIGNED NOT NULL,
  `role_id` int(0) UNSIGNED NOT NULL,
  PRIMARY KEY (`permission_id`, `role_id`) USING BTREE,
  INDEX `role_has_permissions_role_id_foreign`(`role_id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Fixed;

-- ----------------------------
-- Records of role_has_permissions
-- ----------------------------
INSERT INTO `role_has_permissions` VALUES (1, 1);
INSERT INTO `role_has_permissions` VALUES (1, 2);
INSERT INTO `role_has_permissions` VALUES (2, 1);

-- ----------------------------
-- Table structure for roles
-- ----------------------------
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles`  (
  `id` int(0) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of roles
-- ----------------------------
INSERT INTO `roles` VALUES (1, '超级管理员', 'web', '2023-11-15 19:59:46', '2023-11-15 19:59:46');
INSERT INTO `roles` VALUES (2, '写文章', 'web', '2023-11-17 14:50:10', '2023-11-17 14:50:10');

-- ----------------------------
-- Table structure for subscribes
-- ----------------------------
DROP TABLE IF EXISTS `subscribes`;
CREATE TABLE `subscribes`  (
  `id` int(0) UNSIGNED NOT NULL AUTO_INCREMENT,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '订阅邮箱',
  `ip` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT 'IP',
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `subscribes_email_unique`(`email`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of subscribes
-- ----------------------------

-- ----------------------------
-- Table structure for tags
-- ----------------------------
DROP TABLE IF EXISTS `tags`;
CREATE TABLE `tags`  (
  `id` int(0) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '标签ID',
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '标签名',
  `flag` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '标签标识',
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tags
-- ----------------------------
INSERT INTO `tags` VALUES (1, 'Default', 'default', '2018-01-01 00:00:00', '2018-01-01 00:00:00');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `id` int(0) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户名',
  `avatar` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '用户头像',
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '邮箱',
  `password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '密码',
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '是否记住登录',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '状态 1正常 0限制',
  `last_login_at` timestamp(0) NULL DEFAULT NULL COMMENT '最后登录时间',
  `last_login_ip` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '最后登录IP',
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `users_email_unique`(`email`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (1, 'Admin', '\\uploads\\avatar\\default.png', '312985913@qq.com', '$2y$10$nDaPFPt/hZXMN6yL6gTHS.fdxjHGpHjwPmAFFUqco98TfgWXs34wa', 'rk9QD17tFZvA1O0QhNKYc5J5ejOMjvam9CCU2f4OcLYgwVlmWGt4KQBLfUh8', 1, '2023-11-26 22:37:26', '::1', '2023-11-15 19:59:46', '2023-11-26 22:38:28', NULL);
INSERT INTO `users` VALUES (2, 'teng_111', '\\uploads\\avatar\\default.png', '312985914@qq.com', '$2y$10$PkG7AJgDzLBQICdKJey8M.xuMk79GCyGJECGkUQTuHkfP.Jg.kppy', NULL, 1, '2023-11-17 14:52:50', '::1', '2023-11-17 14:52:09', '2023-11-17 14:52:50', NULL);

SET FOREIGN_KEY_CHECKS = 1;
